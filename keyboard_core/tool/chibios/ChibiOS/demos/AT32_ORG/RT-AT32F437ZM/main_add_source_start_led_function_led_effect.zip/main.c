
/*
    Copyright (C) 2023 iOne Electrionc
*/

# include <stdio.h>
# include <string.h>
# include "hal.h"

# include "shell.h"
# include "chprintf.h"

# include "usbcfg.h"
# include "main.h"
# include "led_effect.h"

/*===========================================================================*/
/* Command line related.                                                     */
/*===========================================================================*/

#define SHELL_WA_SIZE   THD_WORKING_AREA_SIZE(2048)
#define SerialDebugPort					SD3

uint32_t get_system_time_ticks(void);


int uprintf(const char* fmt, ...)
{
    va_list ap;
    int formatted_bytes;

    va_start(ap, fmt);
    formatted_bytes = chvprintf((BaseSequentialStream *)&SerialDebugPort, fmt, ap);
    va_end(ap);

    return formatted_bytes;
}


/* Can be measured using dd if=/dev/xxxx of=/dev/null bs=512 count=10000.*/
static void cmd_write(BaseSequentialStream* chp, int argc, char* argv[])
{
    static uint8_t buf[] =
        "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
      "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";

    (void)argv;
    if (argc > 0)
    {
        chprintf(chp, "Usage: write\r\n");
        return;
    }

    while (chnGetTimeout((BaseChannel*)chp, TIME_IMMEDIATE) == Q_TIMEOUT)
    {
#if 1
    /* Writing in channel mode.*/
    chnWrite(&SDU1, buf, sizeof buf - 1);
#else
        /* Writing in buffer mode.*/
        (void)obqGetEmptyBufferTimeout(&SDU1.obqueue, TIME_INFINITE);
        memcpy(SDU1.obqueue.ptr, buf, SERIAL_USB_BUFFERS_SIZE);
        obqPostFullBuffer(&SDU1.obqueue, SERIAL_USB_BUFFERS_SIZE);
#endif
    }
    chprintf(chp, "\r\n\nstopped\r\n");
}

static const ShellCommand commands[] = {
  {"write", cmd_write},
  {NULL, NULL}
};

static const ShellConfig shell_cfg1 = {
  (BaseSequentialStream *)&SDU1,
  commands
};

static const ShellConfig shell_cfg2 = {
  (BaseSequentialStream *)&SDU2,
  commands
};

void uart_init(void)
{
	static const SerialConfig default_config =
	{
			57600, 0, USART_CR2_STOP1_BITS, 0
	};

    palSetPadMode(GPIOC, 10, PAL_MODE_ALTERNATE(7)); /* USART1 TX */
    sdStart(&SerialDebugPort, &default_config);
    uprintf("\r\niOne M18EC Start .....\r\n\r\n", 0x1234, "ABCD");
}

void otg_test(void)
{
    thread_t* shelltp1 = NULL;
    thread_t* shelltp2 = NULL;
    event_listener_t shell_el;
    /*
	* Initializes two serial-over-USB CDC drivers.��ޢ�
	*/
    sduObjectInit(&SDU1);

    sduStart(&SDU1, &serusbcfg1);

    sduObjectInit(&SDU2);

    sduStart(&SDU2, &serusbcfg2);


    /*
	* Activates the USB driver and then the USB bus pull-up on D+.
	* Note, a delay is inserted in order to not have to disconnect the cable
	* after a reset.
	*/

    usbDisconnectBus(serusbcfg1.usbp);

    chThdSleepMilliseconds(1500);

    usbStart(serusbcfg1.usbp, &usbcfg);

    usbConnectBus(serusbcfg1.usbp);

    shellInit();

    chEvtRegister(&shell_terminated, &shell_el, 0);

    /*
	* Normal main() thread activity, managing two shells.
	*/
    while (true)
    {

        if (SDU1.config->usbp->state == USB_ACTIVE)
        {

            /* Starting shells.*/

            if (shelltp1 == NULL)
            {
                shelltp1 = chThdCreateFromHeap(NULL, SHELL_WA_SIZE,
                                                 "shell1", NORMALPRIO + 1,
                                                 shellThread, (void*)&shell_cfg1);
            }

            if (shelltp2 == NULL)
            {
                shelltp2 = chThdCreateFromHeap(NULL, SHELL_WA_SIZE,
                                               "shell2", NORMALPRIO + 1,
                                               shellThread, (void*)&shell_cfg2);
            }

            /* Waiting for an exit event then freeing terminated shells.*/
            chEvtWaitAny(EVENT_MASK(0));
            if (chThdTerminatedX(shelltp1))
            {
                chThdRelease(shelltp1);
                shelltp1 = NULL;
            }
            if (chThdTerminatedX(shelltp2))
            {
                chThdRelease(shelltp2);
                shelltp2 = NULL;
            }
        }
        else
        {
            chThdSleepMilliseconds(1000);
        }
    }

}


#define ADC_GRP1_NUM_CHANNELS   1
#define ADC_GRP1_BUF_DEPTH      8

#define ADC_GRP2_NUM_CHANNELS   8
#define ADC_GRP2_BUF_DEPTH      16

static adcsample_t samples1[ADC_GRP1_NUM_CHANNELS * ADC_GRP1_BUF_DEPTH];
static adcsample_t samples2[ADC_GRP2_NUM_CHANNELS * ADC_GRP2_BUF_DEPTH];

/*
 * ADC streaming callback.
 */
size_t nx = 0, ny = 0;
static void adccallback(ADCDriver* adcp)
{

    if (adcIsBufferComplete(adcp))
    {
        nx += 1;
    }
    else
    {
        ny += 1;
    }
}

static void adcerrorcallback(ADCDriver* adcp, adcerror_t err)
{

    (void)adcp;
    (void)err;
}

/*
 * ADC conversion group.
 * Mode:        Linear buffer, 8 samples of 1 channel, SW triggered.
 * Channels:    IN11.
 */
static const ADCConversionGroup adcgrpcfg1 = {
  FALSE,
  ADC_GRP1_NUM_CHANNELS,
  NULL,
  adcerrorcallback,
  0,                        /* CR1 */
  ADC_CR2_SWSTART,          /* CR2 */
  ADC_SMPR1_SMP_AN11(ADC_SAMPLE_640_5),
  0,                        /* SMPR2 */
  0,                        /* HTR */
  0,                        /* LTR */
  0,                        /* SQR1 */
  0,                        /* SQR2 */
  ADC_SQR3_SQ1_N(ADC_CHANNEL_IN11)
};

/*
 * ADC conversion group.
 * Mode:        Continuous, 16 samples of 8 channels, SW triggered.
 * Channels:    IN11, IN12, IN11, IN12, IN11, IN12, Sensor, VRef.
 */
static const ADCConversionGroup adcgrpcfg2 = {
  TRUE,
  ADC_GRP2_NUM_CHANNELS,
  adccallback,
  adcerrorcallback,
  0,                        /* CR1 */
  ADC_CR2_SWSTART,          /* CR2 */
  ADC_SMPR1_SMP_AN12(ADC_SAMPLE_47_5) | ADC_SMPR1_SMP_AN11(ADC_SAMPLE_47_5) |
  ADC_SMPR1_SMP_SENSOR(ADC_SAMPLE_92_5) | ADC_SMPR1_SMP_VREF(ADC_SAMPLE_92_5),
  0,                        /* SMPR2 */
  0,                        /* HTR */
  0,                        /* LTR */
  0,                        /* SQR1 */
  ADC_SQR2_SQ8_N(ADC_CHANNEL_SENSOR) | ADC_SQR2_SQ7_N(ADC_CHANNEL_VREFINT),
  ADC_SQR3_SQ6_N(ADC_CHANNEL_IN12)   | ADC_SQR3_SQ5_N(ADC_CHANNEL_IN11) |
  ADC_SQR3_SQ4_N(ADC_CHANNEL_IN12)   | ADC_SQR3_SQ3_N(ADC_CHANNEL_IN11) |
  ADC_SQR3_SQ2_N(ADC_CHANNEL_IN12)   | ADC_SQR3_SQ1_N(ADC_CHANNEL_IN11)
};

void adc_test(void)
{
    uprintf ("ADC Test:");
    palSetGroupMode(GPIOC, PAL_PORT_BIT(1) | PAL_PORT_BIT(2),
                    0, PAL_MODE_INPUT_ANALOG);

    /*
	 * Activates the ADC1 driver and the temperature sensor.
	 */
    adcStart(&ADCD1, NULL);
    adcSTM32EnableTSVREFE();

    /*
	 * Linear conversion.
	 */
    adcConvert(&ADCD1, &adcgrpcfg1, samples1, ADC_GRP1_BUF_DEPTH);
    chThdSleepMilliseconds(1000);

    /*
	 * Starts an ADC continuous conversion.
	 */
    adcStartConversion(&ADCD1, &adcgrpcfg2, samples2, ADC_GRP2_BUF_DEPTH);

}

int main(void)
{
    halInit();
    chSysInit();


    uart_init();
    LED_init();

//    chThdCreateStatic(waLED_ModesThread, sizeof(waLED_ModesThread), NORMALPRIO + 1, LED_ModesThread, NULL);
//

//
//    chThdCreateStatic(waLEDUpdateThread, sizeof(waLEDUpdateThread), NORMALPRIO + 2, LEDUpdateThread, NULL);
//
//    buildDemoModes();
//    buildNormalModes();
//
//	//leRemapLocationTest(500);
//	//ledKeymatrixLocationTest(1);
//
//    //setRunMode(demoMode, 0, 0, 0);
//    setRunMode(normalMode, 2, 3, 2);
//    chThdSleepMilliseconds(2000);
//    setRunMode(normalMode, ++normalEffect, normalBrightness+1, normalSpeed+1);
//    chThdSleepMilliseconds(1000);
//    setRunMode(offMode, 0, 0, 0);
//    chThdSleepMilliseconds(3000);
//    setRunMode(normalMode, 8, 10, 1);
//    chThdSleepMilliseconds(3000);
//    setRunMode(normalMode, ++normalEffect, --normalBrightness, ++normalBrightness);
//    chThdSleepMilliseconds(3000);
//    setRunMode(normalMode, ++normalEffect, normalBrightness, normalBrightness);
//    chThdSleepMilliseconds(3000);
//    setRunMode(normalMode, --normalEffect, normalBrightness, normalBrightness);
//    chThdSleepMilliseconds(3000);
//    setRunMode(demoMode, 0, 0, 0);
//    chThdSleepMilliseconds(15000);
//    //setRunMode(normalMode, 8, 4, 1);

    while (1)
    {
    	while(1){
    	uprintf ("Timer:%d\r\n",get_system_time_ticks()/1000);
    	chThdSleepMilliseconds(1000);
    	}

    adc_test();
    otg_test();
    }

}

//    while (1)
//    {
//        //    	//leRemapLocationTest(500);
//        //    	leRemapColorShiftLocationTest(500);
//        //    	chThdSleepMilliseconds(500);
//        //    	ledAllOff();
//        //    	chThdSleepMilliseconds(500);
//        //    	ledKeymatrixLocationTest(1);
//        //    	if (rainbowColor[red].red == rainbowColor[white].red){
//        //    		uprintf ("true\r\n");
//        //    	} else {
//        //    		uprintf ("false\r\n");
//        //    	}
//
//        //		uprintf ("RandColor single bright:8 speed:1\r\n");
//        //		LED_Effect(EffectTypeRandColor,true,single,0,rainbowColor[green],10,1,0);
//        //		chThdSleepMilliseconds(3000);
//        //		LED_Effect(EffectTypeRandColor,false,0,0,LED_NULL,0,0,0);
//        //		chThdSleepMilliseconds(1000);
//
//        //  		if (LED_Effect(EffectTypeMosArt,true,single,mosArtFlash,rainbowColor[red],currentBrightness,1,0)){
//        //  			uprintf ("mosArt ranbow static bright:8 speed:1\r\n");
//        //  			chThdSleepMilliseconds(5000);
//        //  			LED_Effect(EffectTypeMosArt,false,0,0,LED_NULL,0,0,0);
//        //  			chThdSleepMilliseconds(500);
//        //  		}
//
//        LED_Effect(EffectTypeRandColor, true, ranbow, 0, rainbowColor[green], currentBrightness, currentSpeed, 0);
//        chThdSleepMilliseconds(currentSpeed * 3000);
//        LED_Effect(EffectTypeRandColor, false, 0, 0, LED_NULL, 0, 0, 0);
//        chThdSleepMilliseconds(currentSpeed * 500);
//
//        if (LED_Effect(EffectTypeRainbowFlow, true, 0, 0, LED_NULL, currentBrightness, currentSpeed, false))
//        {
//            uprintf("ranbowFlow normal bright:8 speed:1\r\n");
//            chThdSleepMilliseconds(currentSpeed * 5000);
//            LED_Effect(EffectTypeRainbowFlow, false, 0, 0, LED_NULL, 0, 0, 0);
//            chThdSleepMilliseconds(currentSpeed * 500);
//        }
//
//        if (LED_Effect(EffectTypeRainbowFlow, true, 0, 0, LED_NULL, currentBrightness, currentSpeed, true))
//        {
//            uprintf("ranbowFlow reverse bright:8 speed:1\r\n");
//            chThdSleepMilliseconds(currentSpeed * 5000);
//            LED_Effect(EffectTypeRainbowFlow, false, 0, 0, LED_NULL, 0, 0, 0);
//            chThdSleepMilliseconds(currentSpeed * 500);
//        }
//
//        if (LED_Effect(EffectTypeMosArt, true, ranbow, mosArtStatic, rainbowColor[red], currentBrightness, currentSpeed, 0))
//        {
//            uprintf("mosArt ranbow static bright:8 speed:1\r\n");
//            chThdSleepMilliseconds(currentSpeed * 3000);
//            LED_Effect(EffectTypeMosArt, false, 0, 0, LED_NULL, 0, 0, 0);
//            chThdSleepMilliseconds(currentSpeed * 500);
//        }
//
//        if (LED_Effect(EffectTypeMosArt, true, ranbow, mosArtBreath, rainbowColor[red], currentBrightness, currentSpeed, 0))
//        {
//            uprintf("mosArt ranbow breath bright:8 speed:1\r\n");
//            chThdSleepMilliseconds(currentSpeed * 3000);
//            LED_Effect(EffectTypeMosArt, false, 0, 0, LED_NULL, 0, 0, 0);
//            chThdSleepMilliseconds(currentSpeed * 500);
//        }
//
//        if (LED_Effect(EffectTypeMosArt, true, ranbow, mosArtFlash, rainbowColor[red], currentBrightness, currentSpeed, 0))
//        {
//            uprintf("mosArt ranbow Flash bright:8 speed:1\r\n");
//            chThdSleepMilliseconds(currentSpeed * 3000);
//            LED_Effect(EffectTypeMosArt, false, 0, 0, LED_NULL, 0, 0, 0);
//            chThdSleepMilliseconds(currentSpeed * 500);
//        }
//
//        uprintf("RandColor Single color:white bright:8 speed:1\r\n");
//        LED_Effect(EffectTypeRandColor, true, single, 0, rainbowColor[white], currentBrightness, currentSpeed, 0);
//        chThdSleepMilliseconds(currentSpeed * 3000);
//        LED_Effect(EffectTypeRandColor, false, 0, 0, LED_NULL, 0, 0, 0);
//        chThdSleepMilliseconds(currentSpeed * 500);
//
//        uprintf("RandColor ranbow bright:8 speed:1\r\n");
//        LED_Effect(EffectTypeRandColor, true, ranbow, 0, LED_NULL, currentBrightness, currentSpeed, 0);
//        chThdSleepMilliseconds(currentSpeed * 3000);
//        LED_Effect(EffectTypeRandColor, false, 0, 0, LED_NULL, 0, 0, 0);
//        chThdSleepMilliseconds(currentSpeed * 500);
//
//        uprintf("RandColor single color:green bright:8 speed:1\r\n");
//        LED_Effect(EffectTypeRandColor, true, single, 0, rainbowColor[green], currentBrightness, currentSpeed, 0);
//        chThdSleepMilliseconds(currentSpeed * 3000);
//        LED_Effect(EffectTypeRandColor, false, 0, 0, LED_NULL, 0, 0, 0);
//        chThdSleepMilliseconds(currentSpeed * 500);
//    }
//
//
//    adc_test();
//    otg_test();
//
//}
