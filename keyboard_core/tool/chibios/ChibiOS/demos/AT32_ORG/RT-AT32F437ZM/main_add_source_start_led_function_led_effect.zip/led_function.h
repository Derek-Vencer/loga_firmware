#ifndef LED_FUNCTION_H_
#define LED_FUNCTION_H_


void led_cb(void);
void led_creatTask(void);



#define LedNumbers 108+1
//#define LedNumbers 33+1
//#define LedNumbers 2+1
#define defaultBright 25

#define LED_DemoModes	10

#define LED_PresetModes	10

//typedef union {
//  uint32_t raw;
//  struct {
//    uint8_t red;
//    uint8_t green;
//    uint8_t blue;
//    uint8_t btight;
//  };
//} led_config_t;

typedef struct {
	uint8_t red;
	uint8_t green;
	uint8_t blue;
} led_config_t;


typedef struct {
	bool enable;
	uint8_t colorMode;
	led_config_t LED;
	uint8_t brightness;
	//uint8_t speed;
	int16_t ranbowIndex;
	int8_t bright;
	bool direction;
	float lastBrightTemp;
} EffectrandonColor_t;

typedef struct {
	bool enable;
	uint8_t Mode;
	uint8_t Rainbow;
	uint8_t Brightness;
	uint8_t bright;
	uint8_t Speed;
	led_config_t LED;
	uint8_t bbreathvolume;
	uint8_t bFlashingVolume;
	uint16_t TimerBase;
} EffectMosArt_t;


typedef struct {
	bool enable;
	uint8_t Brightness;
	uint8_t bright;
	//uint8_t speed;
	led_config_t LED;
	bool direction;
	uint16_t timebase;
} EffectRanbowFlow_t;


typedef struct {
	uint8_t runMode;
	uint8_t effect;
	bool enable;
	uint8_t colorMode;
	uint8_t mode;
	uint8_t brightness;
	uint8_t speed;
	bool direction;
	uint32_t timeStamp;
	uint32_t interval;
} EffectStatus_t;


typedef struct {
	uint8_t effect;
	bool enable;
	uint32_t interval;
	uint8_t colorMode;
	uint8_t mode;
	led_config_t color;
	uint8_t brightness;
	uint8_t speed;
	bool direction;
} EffectStruct_t;



enum effectTypes{
	EffectIdle,
	EffectTypeRandColor,
	EffectTypeMosArt,
	EffectTypeRainbowFlow,
	EffectTypeColorBrith,
	EffectTypeOff,
};

enum mosArtModes{
	mosArtStatic,
	mosArtBreath,
	mosArtFlash,
};

enum ranbowColors{
	red,
	orange,
	yellow,
	green,
	blue,
	indigo,
	violet,
	white,
	dummy,
	off
};

enum colorModes{
	single,
	ranbow,
};

enum ledRunModes{
	normalMode,
	demoMode,
	testMode,
	offMode,
};

enum ledDemoModeBuilderMode{
	newDemo,
	addDemoEffect,
	newPreset,
	addPresetEffect,
};


static const led_config_t rainbowColor[] = {
    {255, 0, 0},
    {192, 96, 0},
    {255, 255, 0},
    { 0, 255, 0},
    { 0, 0, 255},
    { 0, 255, 255},
    {255, 0, 255},
    {170, 170, 170},
    { 0,  0,  0},
    { 0,  0,  0},
};




#endif /* LED_FUNCTION_H_ */
