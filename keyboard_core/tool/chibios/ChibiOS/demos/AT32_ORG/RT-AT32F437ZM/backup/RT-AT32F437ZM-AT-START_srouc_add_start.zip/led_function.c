
/*
    Copyright (C) 2023 iOne Electrionc
*/

# include <stdio.h>
# include <string.h>
# include <stdint.h>

# include "ch.h"
# include "hal.h"

# include "shell.h"
# include "chprintf.h"

# include "usbcfg.h"
# include "main.h"


#define LED_SPI_Port					SPID1


led_config_t LED_Datas[LedNumbers];

const int8_t ledKeyMatrix[10][16]={
    //	  0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15
    { 15, 14, 13, 12, 11, 10,  9,  8,  7,  6,  5,  4,  3, -1, 33, 35},
		{ 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 40, 38},
		{ 58, 57, 55, 54, 53, 52, 51, 50, 49, 48, 47, 46, 45, 44, 75, 77},
		{ 59, 60, 62, 63, 66, 67, 68, 69, 70, 71, 72, 73, -1, 74, 81, 79},
		{ 94, -1, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, -1, 83,106,107},
		{ 95, 96, 97, -1, -1, -1, 98, -1, -1, 99,100,101,102, 82, 80, 78},
		{ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,  1,  0, 76, 37},
		{ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 31, 32,105, 36},
		{ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 42, 41,104, 34},
		{ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,103, 39},
};

const int8_t ledRemap[6][21] = {
    { 15,  -1,  -1,  14,  13,  12,  11,  10,    9,  8,   7,    6,  5,   3,   2,   1,   0,   0,  -1,  -1,  -1},
	{ 16,  17,  18,  19,  20,  21,  22,  23,  24,  25,  26,  27,  28,  29,  30,  31,  32,  33,  34,  35,  36},
	{ 58,  57,  55,  54,  53,  52,  51,  50,  49,  48,  47,  46,  45,  44,  43,  42,  41,  40,  39,  38,  37},
	{ 59,  60,  62,  63,  66,  67,  68,  69,  70,  71,  72,  73,  -1,  74,  -1,  -1,  -1,  75,  76,  77,  -1},
	{ 94,  93,  92,  91,  90,  89,  88,  87,  86,  85,  84,  -1,  83,  -1,  -1,  82,  -1,  81,  80,  79,  78},
	{ 95,  97,  -1,  -1,  -1,  98,  -1,  -1,  -1,  99, 100, 101,  -1, 102, 103, 104, 105,  -1, 106, 107,  -1},
};

static virtual_timer_t randColor_vt;

const led_config_t rainbowColor[] = {
    {255, 0, 0},
    {192, 96, 0},
    {255, 255, 0},
    { 0, 255, 0},
    { 0, 0, 255},
    { 0, 255, 255},
    {255, 0, 255},
    {170, 170, 170},
    { 0,  0,  0},
    { 0,  0,  0},
};


binary_semaphore_t ledUpdateSem,ledRunmodeSem;
static int32_t lastLED_Update = -1;
uint8_t ledUpdateInterval = 25;
led_config_t LED_NULL;

EffectStruct_t	LED_DemoMode[LED_DemoModes], LED_PresetMode[LED_PresetModes];
uint8_t LED_DemoModeIndex = 0,LED_DemoCurrentMode;
uint8_t LED_PresetModeIndex = 0,LED_PresetCurrentMode;
int8_t normalEffect;
uint8_t normalBrightness = 3, normalSpeed = 2;

bool brightAdj = true;

static EffectrandonColor_t randColor;
static EffectMosArt_t mosArt;
static EffectRanbowFlow_t ranbowFlow;
static EffectStatus_t effectStatus;

void Calculate_Colorful_Color(uint8_t speed, uint32_t timebase, led_config_t* LED);
void calculate_breath_volume(uint8_t speed, uint16_t timebase, uint8_t* bright);
void Calculate_Flashing_Volume(uint8_t speed, uint16_t timebase, uint8_t* bright);
bool setRemapLED(uint8_t row, uint8_t column, led_config_t color);
bool LED_Effect(uint8_t effect, bool enable, uint32_t interval, uint8_t colorMode, uint8_t mode, led_config_t color, uint8_t brightness, uint8_t speed, bool direction);
uint32_t get_system_time_ticks(void);


bool LED_FadoutEffect(uint8_t End, uint8_t speed){
uint8_t maxValue,decValue;
uint8_t *pointer;
	End = LedNumbers;
	pointer = (uint8_t *)LED_Datas;
	//Find Max value;
	uprintf ("Find Max value:%d\r\n",pointer);

	for (uint16_t i=0;i<End*3;i++){
		if (*pointer>maxValue){
			maxValue = *pointer;
		}
		*pointer = 0x20;
		pointer++;
	}
	//uprintf ("MaxValue:%d\r\n",maxValue);
	if (maxValue == 0){
		return false;
	}
	decValue = maxValue / 20;
	if (!decValue){decValue++;}

	//uprintf ("decValue:%d\r\n",decValue);
	//brightAdj = false;
	for (uint16_t i=0;i<speed;i++){
		for (uint16_t j=0;j<End*3;j++){
			if (pointer[j]>decValue){
				pointer[j] -= decValue;
			} else {
				pointer[j] = 0;
			}
			pointer[j] = 0x30;
		}

		//chBSemSignal(&ledUpdateSem);
		//return true;
		//chThdSleepMilliseconds(25);
	}
	//brightAdj = true;
	return true;
}


bool PattenConvet(uint8_t End, uint8_t* data, uint8_t* buffer)
{
    uint8_t i, j;
    uint32_t singleLED;
    uint16_t brightTemp;
    static int32_t LED_Update;
    LED_Update = 0;
    if (End > LedNumbers)
    {
        End = LedNumbers;
    }
    for (i = 0; i < End; i++)
    {
        for (j = 0; j < 3; j++)
        {
            singleLED <<= 8;
            if (brightAdj){
            brightTemp = *data++ * defaultBright / 100;
            } else {
            	brightTemp = *data++;
            }
            singleLED |= brightTemp;
            LED_Update += (brightTemp << j);
        }

        for (j = 0; j < 12; j++)
        {
            if (singleLED & 0x0800000)
            {
                *buffer = 0xe0;
            }
            else
            {
                *buffer = 0x80;
            }
            singleLED <<= 1;
            if (singleLED & 0x0800000)
            {
                *buffer |= 0x0e;
            }
            else
            {
                *buffer |= 0x08;
            }
            singleLED <<= 1;
            buffer++;
        }
    }
    if (LED_Update == lastLED_Update)
    {
        lastLED_Update = LED_Update;
        //uprintf ("pass\t\tupdate:%d last:%d\r\n",LED_Update,lastLED_Update);
        return false;
    }
    lastLED_Update = LED_Update;
    //uprintf ("OK\tupdate:%d last:%d\r\n",LED_Update,lastLED_Update);
    return true;
}


void led_init(void)
{
    const SPIConfig hs_spicfg = {
	  .circular         = false,
	  .slave            = false,
	  .data_cb          = NULL,
	  .error_cb         = NULL,
	  .ssport           = GPIOB,
	  .sspad            = 5U,
	  .cr1              = 36U,
	  .cr2              = 0U
    };
    spiStart(&LED_SPI_Port, &hs_spicfg); /* Setup transfer parameters.       */
    palSetLineMode(PAL_LINE(GPIOB, 5U), PAL_MODE_OUTPUT_PUSHPULL);
    palSetLineMode(PAL_LINE(GPIOA, 8U), PAL_MODE_OUTPUT_PUSHPULL);
    palSetLine(PAL_LINE(GPIOA, 8U));
    palClearLine(PAL_LINE(GPIOB, 5U));
}

static THD_WORKING_AREA(waLED_ModesThread, 128);
static THD_FUNCTION(LED_ModesThread, arg)
{
    (void)arg;
    chRegSetThreadName("LED Modes");
    chBSemObjectInit(&ledRunmodeSem, true);
    while (true)
    {
    	chBSemWait(&ledRunmodeSem);
    	//normalMode
    	switch (effectStatus.runMode){
    	case normalMode:
        	LED_Effect(LED_PresetMode[normalEffect].effect,
        			LED_PresetMode[normalEffect].enable,
					0,
					LED_PresetMode[normalEffect].colorMode,
					LED_PresetMode[normalEffect].mode,
					LED_PresetMode[normalEffect].color,
					normalBrightness,
					normalSpeed,
					LED_PresetMode[normalEffect].direction);
    		break;
    	case 	demoMode:
        	chThdSleepMilliseconds(150);
        	LED_Effect(LED_DemoMode[LED_DemoCurrentMode].effect,
        			LED_DemoMode[LED_DemoCurrentMode].enable,
    				LED_DemoMode[LED_DemoCurrentMode].interval,
    				LED_DemoMode[LED_DemoCurrentMode].colorMode,
    				LED_DemoMode[LED_DemoCurrentMode].mode,
    				LED_DemoMode[LED_DemoCurrentMode].color,
    				LED_DemoMode[LED_DemoCurrentMode].brightness,
    				LED_DemoMode[LED_DemoCurrentMode].speed,
    				LED_DemoMode[LED_DemoCurrentMode].direction);
        	if (LED_DemoMode[LED_DemoCurrentMode+1].effect){
        		LED_DemoCurrentMode++;
        	} else {
        		LED_DemoCurrentMode = 0;
        	}
    		break;
    	case testMode:
    		break;
    	case offMode:
    		break;
    	}
    }
}

static THD_WORKING_AREA(waLEDUpdateThread, 256);
static THD_FUNCTION(LEDUpdateThread, arg)
{
    (void)arg;
    chRegSetThreadName("LED Update");
    uint8_t blank[150];
    static CC_ALIGN_DATA(32) uint8_t patternBuffer[1296];
	chBSemObjectInit(&ledUpdateSem, true);
	chVTObjectInit(&randColor_vt);
	memset(blank, 0x00, sizeof(blank));
	led_init();
	while (true)
	{
		chBSemWait(&ledUpdateSem);
		if (PattenConvet(LedNumbers - 1, (uint8_t*)LED_Datas, patternBuffer))
		{
			spiAcquireBus(&LED_SPI_Port);        /* Acquire ownership of the bus.    */
			spiSend(&LED_SPI_Port, sizeof(blank), blank);
			palSetPadMode(GPIOB, 5, PAL_MODE_ALTERNATE(5)); /* SPI1_MOSI */
			spiSend(&LED_SPI_Port, sizeof(patternBuffer), patternBuffer);
			spiReleaseBus(&LED_SPI_Port);
		}
	}
}

void ledAllOff(void)
{
    memset(LED_Datas, 0x00, sizeof(LED_Datas));
    chBSemSignal(&ledUpdateSem);
}

void led_updateFrameBufferSingle(uint8_t start, uint8_t end, led_config_t* led)
{
    for (uint8_t i = start; i < end; i++)
    {
    	LED_Datas[i] = *led;
    }
    chBSemSignal(&ledUpdateSem);
}

bool effectRandowColorProcess(void)
{
    float brightTemp;
    led_config_t ledTemp;
    brightTemp = (float)(randColor.bright * randColor.brightness) / 1000;
    switch (randColor.colorMode)
    {
        case single:
            ledTemp.red = randColor.LED.red * brightTemp;
            ledTemp.green = randColor.LED.green * brightTemp;
            ledTemp.blue = randColor.LED.blue * brightTemp;
            break;
        case ranbow:
            ledTemp.red = rainbowColor[randColor.ranbowIndex].red * brightTemp;
            ledTemp.green = rainbowColor[randColor.ranbowIndex].green * brightTemp;
            ledTemp.blue = rainbowColor[randColor.ranbowIndex].blue * brightTemp;
            break;
    }
    led_updateFrameBufferSingle(0, LedNumbers, &ledTemp);

    if (randColor.direction)
    {
        if (randColor.bright >= 100)
        {
            randColor.direction = false;
        }
        else
        {
            randColor.bright += 3;
        }
    }
    else
    {
        if (randColor.bright <= 0)
        {
            if (randColor.colorMode)
            {
                randColor.ranbowIndex++;
            }
            if (randColor.enable)
            {
                randColor.direction = true;
                if (effectStatus.interval!=0 && (get_system_time_ticks()-effectStatus.timeStamp>effectStatus.interval)){
                    chVTReset(&randColor_vt);
                    randColor.enable = false;
                    ledAllOff();
                    effectStatus.effect = EffectIdle;
                    if (effectStatus.runMode == demoMode){
                    	chBSemSignal(&ledRunmodeSem);
                    }
                    return false;
                }
            }
            else
            {
                chVTReset(&randColor_vt);
                randColor.enable = false;
                ledAllOff();
                effectStatus.effect = EffectIdle;
                return false;
            }
        }
        else
        {
            randColor.bright -= 3;
        }
    }
    if (randColor.bright > 100) { randColor.bright = 100; }
    if (randColor.ranbowIndex > (uint8_t)(sizeof(sizeof(rainbowColor) / 3)+2)){
    randColor.ranbowIndex = 0;
}
return true;
}

bool effectMosArtProcess(void)
{
    float tempmBright;
    uint8_t bright;
    led_config_t ledTemp;
    if (mosArt.enable)
    {
    	if (effectStatus.interval!=0 && (get_system_time_ticks()-effectStatus.timeStamp>effectStatus.interval)){
            chVTReset(&randColor_vt);
            mosArt.enable = false;
//            LED_FadoutEffect(LedNumbers,100);
//            chThdSleepMilliseconds(150);
            ledAllOff();
            effectStatus.effect = EffectIdle;
            if (effectStatus.runMode == demoMode){
            	chBSemSignal(&ledRunmodeSem);
            }
            return false;
        }
        switch (mosArt.Mode)
        {
            case 0:
                bright = 255;
                break;
            case 1:
                calculate_breath_volume(mosArt.Speed, mosArt.TimerBase, &bright);
                break;

            case 2:
                Calculate_Flashing_Volume(mosArt.Speed, mosArt.TimerBase, &bright);
                break;
        }
        tempmBright = ((float)(mosArt.Brightness)) * bright / 2550;
        if (mosArt.Rainbow != 0)
        {
            Calculate_Colorful_Color(mosArt.Speed, mosArt.TimerBase, &mosArt.LED);
        }

        ledTemp.red = mosArt.LED.red * tempmBright;
        ledTemp.green = mosArt.LED.green * tempmBright;
        ledTemp.blue = mosArt.LED.blue * tempmBright;
        led_updateFrameBufferSingle(0, LedNumbers, &ledTemp);
        mosArt.TimerBase += 10;
        return true;
    }
    else
    {
        chVTReset(&randColor_vt);
        mosArt.enable = false;
        ledAllOff();
        effectStatus.effect = EffectIdle;
    }
    return false;
}

bool EffectTypeRainbowFlowProcess(void)
{
    uint8_t row, column;
    float tempmBright;
    if (ranbowFlow.enable)
    {
    	if (effectStatus.interval!=0 && (get_system_time_ticks()-effectStatus.timeStamp>effectStatus.interval)){
            chVTReset(&randColor_vt);
            ranbowFlow.enable = false;
            ledAllOff();
            effectStatus.effect = EffectIdle;
            if (effectStatus.runMode == demoMode){
            	chBSemSignal(&ledRunmodeSem);
            }
            return false;
        }
        tempmBright = (float)(ranbowFlow.Brightness) / 10;
        for (column = 0; column < 21; column++)
        {
            Calculate_Colorful_Color(0, ranbowFlow.timebase, &ranbowFlow.LED);
            if (ranbowFlow.direction)
            {
                ranbowFlow.timebase += 99;
            }
            else
            {
                ranbowFlow.timebase += 96;
            }
            ranbowFlow.LED.red *= tempmBright;
            ranbowFlow.LED.green *= tempmBright;
            ranbowFlow.LED.blue *= tempmBright;
            for (row = 0; row < 6; row++)
            {
                setRemapLED(row, column, ranbowFlow.LED);
            }
        }
        chBSemSignal(&ledUpdateSem);
        return true;
    }
    else
    {
        chVTReset(&randColor_vt);
        ranbowFlow.enable = false;
        ledAllOff();
        effectStatus.effect = EffectIdle;
    }
    return false;
}



static void led_cb(void)
{
    bool enable;
    switch (effectStatus.effect)
    {
        case EffectTypeRandColor:
            enable = effectRandowColorProcess();
            break;
        case EffectTypeMosArt:
            enable = effectMosArtProcess();
            break;
        case EffectTypeRainbowFlow:
            enable = EffectTypeRainbowFlowProcess();
            break;
        case EffectTypeColorBrith:
            enable = EffectTypeRainbowFlowProcess();
            break;
        case EffectTypeOff:
            break;
        case EffectIdle:
            break;
        default:
            return;
    }

    if (enable)
    {
        chSysLockFromISR();
        chVTSetI(&randColor_vt, TIME_MS2I(effectStatus.speed), (vtfunc_t)led_cb, NULL);
        chSysUnlockFromISR();
    }
    //	else {
    //		chVTReset(&randColor_vt);
    //	}
}

void Calculate_Colorful_Color(uint8_t speed, uint32_t timebase, led_config_t* LED)
{
    uint8_t i;
    uint8_t color, colorInv;
    timebase >>= 1;
    for (i = 0; i < speed; i++)
    {
        timebase >>= 1;
    }
    color = (uint8_t)(timebase & 0xFF);
    colorInv = ~color;
    switch (((uint8_t)((timebase >> 8) & 0xFF)) & 0x03)
    {
        default:
            LED->red = color;
            LED->green = 0;
            LED->blue = colorInv;
            break;
        case 1:
            LED->red = 255;
            LED->green = color;
            LED->blue = 0;
            break;
        case 2:
            LED->red = colorInv;
            LED->green = 255;
            LED->blue = 0;
            break;
        case 3:
            LED->red = 0;
            LED->green = colorInv;
            LED->blue = color;
            break;
    }
}

void calculate_breath_volume(uint8_t speed, uint16_t timebase, uint8_t* bright)
{
    uint8_t i;
    uint16_t wtemp;
    timebase >>= 1;
    for (i = 0; i < speed; i++)
    {
        timebase >>= 1;
    }
    if (((uint8_t)((timebase >> 8) & 0xff) & 0x01) == 0x00)
    {
        *bright = (uint8_t)(timebase & 0xff);
    }
    else
    {
        *bright = 255 - (uint8_t)(timebase & 0xff);
    }
    if (*bright <= 15)
    {
        *bright = 0;
    }
    else if (*bright >= 240)
    {
        *bright = 255;
    }
    else
    {
        wtemp = (uint16_t) * bright - 15;
        wtemp = (wtemp * 255) / 225;
        *bright = (uint8_t)wtemp;
    }
}


void Calculate_Flashing_Volume(uint8_t speed, uint16_t timebase, uint8_t* bright)
{
    uint16_t blinkOnBit;
    timebase >>= 1;
    blinkOnBit = 0x0040;
    do
    {
        blinkOnBit <<= 1;
    } while (speed--);
    if (!(timebase & blinkOnBit))
    {
        *bright = 255;
    }
    else
    {
        *bright = 0;
    }
}


bool LED_Effect(uint8_t effect, bool enable, uint32_t interval, uint8_t colorMode, uint8_t mode, led_config_t color, uint8_t brightness, uint8_t speed, bool direction)
{
    switch (effect)
    {
        case EffectTypeRandColor:
            if (enable)
            {
                if (speed <= 0 || speed > 5 || (brightness < 1 || brightness > 10))
                {
                    return false;
                }
                randColor.colorMode = colorMode;
                switch (colorMode)
                {
                    case single:
                        randColor.LED = color;
                        break;
                    case ranbow:
                        //randColor.ranbowIndex = 0;
                        break;
                }
                randColor.bright = 0;
                randColor.direction = true;
                randColor.brightness = brightness;
                effectStatus.speed = speed * ledUpdateInterval;
                randColor.enable = true;
                chVTSet(&randColor_vt, TIME_MS2I(effectStatus.speed), (vtfunc_t)led_cb, NULL);
            }
            else
            {
                randColor.enable = false;
            }
            break;
        case EffectTypeMosArt:
            if (enable)
            {
                if (speed > 5 || (brightness < 1 || brightness > 10) || mode > mosArtFlash || colorMode > ranbow)
                {
                    return false;
                }
                mosArt.Mode = mode;
                mosArt.Rainbow = colorMode;
                mosArt.Speed = --speed;
                mosArt.Brightness = brightness;
                effectStatus.speed = 33;
                mosArt.TimerBase = 0;
                mosArt.enable = true;
                switch (colorMode)
                {
                    case single:
                        mosArt.LED = color;
                        break;
                    case ranbow:
                        break;
                }
                chVTSet(&randColor_vt, TIME_MS2I(effectStatus.speed), (vtfunc_t)led_cb, NULL);
            }
            else
            {
                mosArt.enable = false;
            }
            break;

        case EffectTypeRainbowFlow:
            if (enable)
            {
                if (speed > 5 || (brightness < 1 || brightness > 10))
                {
                    return false;
                }
                ranbowFlow.Brightness = brightness;
                effectStatus.speed = speed * ledUpdateInterval;
                ranbowFlow.timebase = 700;
                ranbowFlow.enable = true;
                ranbowFlow.direction = direction;
                chVTSet(&randColor_vt, TIME_MS2I(effectStatus.speed), (vtfunc_t)led_cb, NULL);
            }
            else
            {
                ranbowFlow.enable = false;
            }
            break;

        case EffectTypeColorBrith:
            break;
        case EffectTypeOff:
            if (randColor.enable)
            {
                randColor.enable = false;
                randColor.ranbowIndex++;
                chVTReset(&randColor_vt);
            }
            ledAllOff();
            effectStatus.effect = EffectIdle;
            return true;
            break;
        case EffectIdle:
            break;
    }

    effectStatus.effect = effect;
    effectStatus.enable = enable;
    effectStatus.colorMode = colorMode;
    effectStatus.mode = mode;
    effectStatus.brightness = brightness;
    effectStatus.direction = direction;
    effectStatus.timeStamp = get_system_time_ticks();
    effectStatus.interval = interval;
    return true;
}

bool setKeyMatrixLED(uint8_t row, uint8_t column, led_config_t color)
{
    int8_t number;
    const uint8_t LED_Remap[2][4]={ { 55,60,62,63},{ 56,61,64,65} };
    number = ledKeyMatrix[row][column];
    if (number > LedNumbers) { return false; }
    if (number != -1)
    {
        for (uint8_t i = 0; i < 4; i++)
        {
            if (LED_Remap[0][i] == number)
            {
                LED_Datas[LED_Remap[1][i]] = color;
            }
        }
        LED_Datas[number] = color;
        return true;

    }
    return false;
}

bool setRemapLED(uint8_t row, uint8_t column, led_config_t color)
{
    int8_t number;
    const uint8_t LED_Remap[2][6]={ { 3, 55, 60, 62, 63, 95},{ 4, 56, 61, 64, 65, 96} };
    number = ledRemap[row][column];
    if (number > LedNumbers) { return false; }
    if (number != -1)
    {
        for (uint8_t i = 0; i < 6; i++)
        {
            if (LED_Remap[0][i] == number)
            {
                LED_Datas[LED_Remap[1][i]] = color;
            }
        }
        LED_Datas[number] = color;
        return true;

    }
    return false;
}



void ledKeymatrixLocationTest(uint8_t count)
{
    uint8_t row, column;
    while (count--)
    {
        for (row = 0; row < 10; row++)
        {
            for (column = 0; column < 16; column++)
            {
                if (setKeyMatrixLED(row, column, rainbowColor[row % 7]))
                {
                    chBSemSignal(&ledUpdateSem);
                    chThdSleepMilliseconds(150);
                    memset(LED_Datas, 0x00, sizeof(LED_Datas));
                }
            }
        }
    }
}

void leRemapLocationTest(uint16_t count)
{
    uint16_t colorCount = 0;
    while (count--)
    {
        memset(LED_Datas, 0x00, sizeof(LED_Datas));
        for (uint8_t column = 0; column < 21; column++)
        {
            for (uint8_t row = 0; row < 6; row++)
            {
                setRemapLED(row, column, rainbowColor[(colorCount + column) % 7]);
            }
        }
        colorCount--;
        chBSemSignal(&ledUpdateSem);
        chThdSleepMilliseconds(200);
    }
    ledAllOff();
    chThdSleepMilliseconds(500);

}

uint32_t get_system_time_ticks(void) {
	return (uint32_t)TIME_I2MS((uint32_t)chVTGetSystemTimeX());
}

bool LED_DemoModesBuilder(uint8_t action,bool start,uint8_t effect, bool enable, uint32_t interval, uint8_t colorMode, uint8_t mode, led_config_t color, uint8_t brightness, uint8_t speed, bool direction){
	switch (action){
		case	newDemo:
		case	addDemoEffect:
			switch (action){
				case newDemo:
				LED_DemoModeIndex = 0;
				break;
			case	addDemoEffect:
				if (LED_DemoModeIndex++>LED_DemoModes){
					return false;
				}
				break;
			}
			LED_DemoMode[LED_DemoModeIndex].effect = effect;
			LED_DemoMode[LED_DemoModeIndex].enable = enable;
			LED_DemoMode[LED_DemoModeIndex].interval = interval;
			LED_DemoMode[LED_DemoModeIndex].colorMode = colorMode;
			LED_DemoMode[LED_DemoModeIndex].mode = mode;
			LED_DemoMode[LED_DemoModeIndex].color = color;
			LED_DemoMode[LED_DemoModeIndex].brightness = brightness;
			LED_DemoMode[LED_DemoModeIndex].speed = speed;
			LED_DemoMode[LED_DemoModeIndex].direction = direction;
			if (start){
				chVTReset(&randColor_vt);
				ledAllOff();
				chThdSleepMilliseconds(150);
				effectStatus.runMode = demoMode;
				LED_DemoCurrentMode = 0;
				chBSemSignal(&ledRunmodeSem);
			}
			break;
		case	newPreset:
		case	addPresetEffect:
			switch (action){
				case	newPreset:
				LED_PresetModeIndex = 0;
				break;
			case	addPresetEffect:
				if (LED_PresetModeIndex++>LED_PresetModeIndex){
					return false;
				}
			break;
			}
			LED_PresetMode[LED_PresetModeIndex].effect = effect;
			LED_PresetMode[LED_PresetModeIndex].enable = enable;
			LED_PresetMode[LED_PresetModeIndex].interval = 0;
			LED_PresetMode[LED_PresetModeIndex].colorMode = colorMode;
			LED_PresetMode[LED_PresetModeIndex].mode = mode;
			LED_PresetMode[LED_PresetModeIndex].color = color;
			LED_PresetMode[LED_PresetModeIndex].brightness = normalBrightness;
			LED_PresetMode[LED_PresetModeIndex].speed = normalSpeed;
			LED_PresetMode[LED_PresetModeIndex].direction = direction;
	}

	return false;
}

bool setRunMode(uint8_t runMode, int8_t mode, uint8_t brightness, uint8_t speed){
	switch (runMode){
		case	normalMode:
			chVTReset(&randColor_vt);
			ledAllOff();
			chThdSleepMilliseconds(150);
			LED_PresetCurrentMode = mode;
			effectStatus.runMode = normalMode;
			if (mode>LED_PresetModeIndex){
				mode = 0;
			}
			if (mode<0){
				mode = LED_PresetModeIndex;
			}
			if (brightness>10){
				brightness = 10;
			}
			if (brightness < 1){
				brightness = 1;
			}
			if (speed>5){
				speed = 5;
			}
			if (speed < 1){
				speed = 1;
			}
			normalEffect = mode;
			normalBrightness = brightness;
			normalSpeed = speed;
			chBSemSignal(&ledRunmodeSem);
			break;
		case	demoMode:
			chVTReset(&randColor_vt);
			ledAllOff();
			chThdSleepMilliseconds(150);
			LED_DemoCurrentMode = 0;
			effectStatus.runMode = demoMode;
			chBSemSignal(&ledRunmodeSem);
			break;
		case testMode:
			break;
		case offMode:
			chVTReset(&randColor_vt);
			effectStatus.effect = EffectIdle;
			ledAllOff();

			break;
	}
}


void buildDemoModes(void){
uint8_t currentBrightness = 5;
uint16_t currentSpeed = 2;
	    LED_DemoModesBuilder(newDemo , false,EffectTypeRainbowFlow, true, 5000, 0, 0,  LED_NULL, currentBrightness, currentSpeed, false);
	    LED_DemoModesBuilder(addDemoEffect , false,EffectTypeRainbowFlow, true, 5000, 0, 0,  LED_NULL, currentBrightness, currentSpeed, true);
	    LED_DemoModesBuilder(addDemoEffect , false,EffectTypeMosArt, true, 5000, ranbow, mosArtStatic,  rainbowColor[green], currentBrightness, currentSpeed, 0);
	    LED_DemoModesBuilder(addDemoEffect , false,EffectTypeMosArt, true, 5000, single, mosArtStatic,  rainbowColor[green], currentBrightness, currentSpeed, 0);
	    LED_DemoModesBuilder(addDemoEffect , false,EffectTypeRandColor, true, 5000, ranbow, 0,  rainbowColor[green], currentBrightness, currentSpeed, 0);

		//    LED_DemoModesBuilder(newDemo , false,EffectTypeMosArt, true, 1500, single, mosArtStatic,  rainbowColor[red], currentBrightness, currentSpeed, 0);
		//    LED_DemoModesBuilder(addDemoEffect , false,EffectTypeMosArt, true, 1500, single, mosArtStatic,  rainbowColor[green], currentBrightness, currentSpeed, 0);
		//    LED_DemoModesBuilder(addDemoEffect , false,EffectTypeMosArt, true, 1500, single, mosArtStatic,  rainbowColor[blue], currentBrightness, currentSpeed, 0);
		//    LED_DemoModesBuilder(addDemoEffect , false,EffectTypeMosArt, true, 1500, single, mosArtStatic,  rainbowColor[yellow], currentBrightness, currentSpeed, 0);
		//    LED_DemoModesBuilder(addDemoEffect , false,EffectTypeMosArt, true, 1500, single, mosArtStatic,  rainbowColor[white], currentBrightness, currentSpeed, 0);
		//    LED_DemoModesBuilder(addDemoEffect , false,EffectTypeMosArt, true, 1500, single, mosArtStatic,  rainbowColor[orange], currentBrightness, currentSpeed, 0);
		//    LED_DemoModesBuilder(addDemoEffect , false,EffectTypeMosArt, true, 1500, single, mosArtStatic,  rainbowColor[indigo], currentBrightness, currentSpeed, 0);
		//    LED_DemoModesBuilder(addDemoEffect , true,EffectTypeMosArt, true, 1500, single, mosArtStatic,  rainbowColor[violet], currentBrightness, currentSpeed, 0);
}

void buildNormalModes(void){
//	LED_DemoModesBuilder(newPreset , false,EffectTypeRainbowFlow, true, 0, 0, 0,  LED_NULL, normalBrightness, normalSpeed, true);
//	LED_DemoModesBuilder(addPresetEffect , false,EffectTypeRainbowFlow, true, 0, 0, 0,  LED_NULL, normalBrightness, normalSpeed, false);
//	LED_DemoModesBuilder(addPresetEffect , false,EffectTypeMosArt, true, 0, ranbow, mosArtStatic,  rainbowColor[green], normalBrightness, normalSpeed, 0);
//	LED_DemoModesBuilder(addPresetEffect , false,EffectTypeMosArt, true, 0, single, mosArtStatic,  rainbowColor[green], normalBrightness, normalSpeed, 0);
//	LED_DemoModesBuilder(addPresetEffect , true,EffectTypeRandColor, true, 0, ranbow, 0,  rainbowColor[green], normalBrightness, normalSpeed, 0);

	LED_DemoModesBuilder(newPreset , false,EffectTypeMosArt, true, 1500, single, mosArtStatic,  rainbowColor[red], normalBrightness, normalSpeed, 0);
	LED_DemoModesBuilder(addPresetEffect , false,EffectTypeMosArt, true, 0, single, mosArtStatic,  rainbowColor[green], normalBrightness, normalSpeed, 0);
	LED_DemoModesBuilder(addPresetEffect , false,EffectTypeMosArt, true, 0, single, mosArtStatic,  rainbowColor[blue], normalBrightness, normalSpeed, 0);
	LED_DemoModesBuilder(addPresetEffect , false,EffectTypeMosArt, true, 0, single, mosArtStatic,  rainbowColor[yellow], normalBrightness, normalSpeed, 0);
	LED_DemoModesBuilder(addPresetEffect , false,EffectTypeMosArt, true, 0, single, mosArtStatic,  rainbowColor[white], normalBrightness, normalSpeed, 0);
	LED_DemoModesBuilder(addPresetEffect , false,EffectTypeMosArt, true, 0, single, mosArtStatic,  rainbowColor[orange], normalBrightness, normalSpeed, 0);
	LED_DemoModesBuilder(addPresetEffect , false,EffectTypeMosArt, true, 0, single, mosArtStatic,  rainbowColor[indigo], normalBrightness, normalSpeed, 0);
	LED_DemoModesBuilder(addPresetEffect , false,EffectTypeMosArt, true, 0, single, mosArtStatic,  rainbowColor[violet], normalBrightness, normalSpeed, 0);
	LED_DemoModesBuilder(addPresetEffect , false,EffectTypeRainbowFlow, true, 5000, 0, 0,  LED_NULL, normalBrightness, normalSpeed, false);
	LED_DemoModesBuilder(addPresetEffect , false,EffectTypeRainbowFlow, true, 5000, 0, 0,  LED_NULL, normalBrightness, normalSpeed, true);


}
