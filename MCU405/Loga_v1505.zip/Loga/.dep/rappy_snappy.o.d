build/obj/rappy_snappy.o: rappy_snappy.c config.h socd.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_default_types.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\features.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_newlib_version.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_intsup.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdbool.h \
 ../../keyboard_core/common/matrix.h rappy_snappy.h dynamic_macro.h \
 ../../keyboard_core/common/action.h \
 ../../keyboard_core/common/keyboard.h \
 ../../keyboard_core/common/keycode.h \
 ../../keyboard_core/common/action_code.h \
 ../../keyboard_core/common/action_macro.h \
 ../../keyboard_core/common/progmem.h \
 ../../keyboard_core/common/action_layer.h \
 ../../keyboard_core/common/action.h ../../keyboard_core/common/matrix.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\string.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_ansi.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\newlib.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\config.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\ieeefp.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\reent.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_ansi.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stddef.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_types.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_types.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\lock.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\cdefs.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_locale.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\strings.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\string.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/eeprom.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdlib.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\stdlib.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\alloca.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_eeprom_i2c.h
config.h:
socd.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_default_types.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\features.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_newlib_version.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_intsup.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdbool.h:
../../keyboard_core/common/matrix.h:
rappy_snappy.h:
dynamic_macro.h:
../../keyboard_core/common/action.h:
../../keyboard_core/common/keyboard.h:
../../keyboard_core/common/keycode.h:
../../keyboard_core/common/action_code.h:
../../keyboard_core/common/action_macro.h:
../../keyboard_core/common/progmem.h:
../../keyboard_core/common/action_layer.h:
../../keyboard_core/common/action.h:
../../keyboard_core/common/matrix.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\string.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_ansi.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\newlib.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\config.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\ieeefp.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\reent.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_ansi.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stddef.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_types.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_types.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\lock.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\cdefs.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_locale.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\strings.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\string.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/eeprom.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdlib.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\stdlib.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\alloca.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_eeprom_i2c.h:
