build/obj/util.o: ../../keyboard_core/common/util.c config.h socd.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_default_types.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\features.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_newlib_version.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_intsup.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdbool.h \
 ../../keyboard_core/common/matrix.h rappy_snappy.h dynamic_macro.h \
 ../../keyboard_core/common/action.h \
 ../../keyboard_core/common/keyboard.h \
 ../../keyboard_core/common/keycode.h \
 ../../keyboard_core/common/action_code.h \
 ../../keyboard_core/common/action_macro.h \
 ../../keyboard_core/common/progmem.h \
 ../../keyboard_core/common/action_layer.h \
 ../../keyboard_core/common/action.h ../../keyboard_core/common/util.h
config.h:
socd.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_default_types.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\features.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_newlib_version.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_intsup.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdbool.h:
../../keyboard_core/common/matrix.h:
rappy_snappy.h:
dynamic_macro.h:
../../keyboard_core/common/action.h:
../../keyboard_core/common/keyboard.h:
../../keyboard_core/common/keycode.h:
../../keyboard_core/common/action_code.h:
../../keyboard_core/common/action_macro.h:
../../keyboard_core/common/progmem.h:
../../keyboard_core/common/action_layer.h:
../../keyboard_core/common/action.h:
../../keyboard_core/common/util.h:
