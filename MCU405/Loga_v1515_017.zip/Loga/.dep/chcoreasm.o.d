build/obj/chcoreasm.o: \
 ../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/compilers/GCC/chcoreasm.S \
 ../../keyboard_core/tool/chibios/chibios/os/license/chlicense.h \
 ../../keyboard_core/tool/chibios/chibios/os/license/chversion.h \
 ../../keyboard_core/tool/chibios/chibios/os/license/chcustomer.h \
 chconf.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/chcore.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/cmparams.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/mpu.h
../../keyboard_core/tool/chibios/chibios/os/license/chlicense.h:
../../keyboard_core/tool/chibios/chibios/os/license/chversion.h:
../../keyboard_core/tool/chibios/chibios/os/license/chcustomer.h:
chconf.h:
../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/chcore.h:
../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/cmparams.h:
../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/mpu.h:
