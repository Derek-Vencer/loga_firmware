build/obj/crt0_v7m.o: \
 ../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/compilers/GCC/crt0_v7m.S
