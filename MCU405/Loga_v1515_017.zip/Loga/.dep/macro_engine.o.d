build/obj/macro_engine.o: macro_engine.c config.h socd.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_default_types.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\features.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_newlib_version.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_intsup.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdbool.h \
 ../../keyboard_core/common/matrix.h rappy_snappy.h macro_engine.h \
 ../../keyboard_core/common/eeconfig.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stddef.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/eeprom.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdlib.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\ieeefp.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_ansi.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\newlib.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\config.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\reent.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_ansi.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_types.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_types.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\lock.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\cdefs.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\stdlib.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\alloca.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_eeprom_i2c.h \
 ../../keyboard_core/common/uart.h ../../keyboard_core/common/print.h \
 ../../keyboard_core/common/util.h \
 ../../keyboard_core/common/chibios/printf.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdarg.h \
 ../../keyboard_core/common/keycode.h \
 ../../keyboard_core/common/action_code.h \
 ../../keyboard_core/common/wait.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/ch.h \
 ../../keyboard_core/tool/chibios/chibios/os/license/chlicense.h \
 ../../keyboard_core/tool/chibios/chibios/os/license/chversion.h \
 ../../keyboard_core/tool/chibios/chibios/os/license/chcustomer.h \
 chconf.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chchecks.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chrestrictions.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chearly.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ports/ARM-common/chtypes.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/portability/GCC/ccportab.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chrfcu.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chdebug.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chtime.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chlists.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chalign.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chtrace.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chport.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/chcore.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/cmparams.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/boards/AT_START_F405/board.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/at32f402_405xx.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/core_cm4.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_version.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_compiler.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_gcc.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/mpu_armv7.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/mpu.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chtm.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chstats.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chobjects.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chsys.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chinstances.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chvt.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chschd.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chthreads.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chregistry.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chsem.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chmtx.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chcond.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chevents.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chmsg.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chlib.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chbsem.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmboxes.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmemcore.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmemheaps.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmempools.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chobjfifos.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chpipes.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chobjcaches.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chdelegates.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chjobs.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chfactory.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chdynamic.h \
 ../../keyboard_core/common/action_util.h \
 ../../keyboard_core/common/report.h ../../keyboard_core/common/keycode.h \
 ../../keyboard_core/protocol/chibios/usb_main.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/osal/rt-nil/osal.h \
 halconf.h mcuconf.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/AT32F405xx/hal_lld.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/AT32F405xx/at32_registry.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/common/ARMCMx/nvic.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/common/ARMCMx/cache.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/common/ARMCMx/mpu_v7m.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/AT32F405xx/at32_crm.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/DMAv2/at32_dma.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/AT32F405xx/at32_dmamux.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/EXINTv1/at32_exint.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/AT32F405xx/at32_isr.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/TMRv1/at32_tmr.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_objects.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_streams.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_channels.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_files.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_ioblock.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_mmcsd.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_persistent.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_flash.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_buffers.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_queues.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_pal.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/GPIOv2/hal_pal_lld.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/GPIOv2/at32_gpio.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_adc.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/ADCv2/hal_adc_lld.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_can.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_crypto.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_dac.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_efl.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_gpt.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/TMRv1/hal_gpt_lld.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/TMRv1/at32_tmr.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_i2c.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/I2Cv2/hal_i2c_lld.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_i2s.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_icu.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_eicu.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_timcap.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_mac.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_pwm.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_rtc.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_serial.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/USARTv2/hal_serial_lld.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_sdc.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_sio.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_spi.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_spi_v2.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/SPIv2/hal_spi_v2_lld.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_trng.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_uart.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/USARTv2/hal_uart_lld.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_usb.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/OTGv1/hal_usb_lld.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/OTGv1/at32_otg.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_wdg.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_wspi.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_eeprom.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_crc.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/CRCv1/hal_crc_lld.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_st.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/SYSTICKv1/hal_st_lld.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_mmc_spi.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_serial_usb.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_usb_cdc.h \
 ../../keyboard_core/common/matrix.h ../../keyboard_core/common/timer.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\string.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_locale.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\strings.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\string.h \
 ../../keyboard_core/common/action.h \
 ../../keyboard_core/common/keyboard.h \
 ../../keyboard_core/common/action_macro.h \
 ../../keyboard_core/common/progmem.h
config.h:
socd.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_default_types.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\features.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_newlib_version.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_intsup.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdbool.h:
../../keyboard_core/common/matrix.h:
rappy_snappy.h:
macro_engine.h:
../../keyboard_core/common/eeconfig.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stddef.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/eeprom.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdlib.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\ieeefp.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_ansi.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\newlib.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\config.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\reent.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_ansi.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_types.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_types.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\lock.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\cdefs.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\stdlib.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\alloca.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_eeprom_i2c.h:
../../keyboard_core/common/uart.h:
../../keyboard_core/common/print.h:
../../keyboard_core/common/util.h:
../../keyboard_core/common/chibios/printf.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdarg.h:
../../keyboard_core/common/keycode.h:
../../keyboard_core/common/action_code.h:
../../keyboard_core/common/wait.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/ch.h:
../../keyboard_core/tool/chibios/chibios/os/license/chlicense.h:
../../keyboard_core/tool/chibios/chibios/os/license/chversion.h:
../../keyboard_core/tool/chibios/chibios/os/license/chcustomer.h:
chconf.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chchecks.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chrestrictions.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chearly.h:
../../keyboard_core/tool/chibios/chibios/os/common/ports/ARM-common/chtypes.h:
../../keyboard_core/tool/chibios/chibios/os/common/portability/GCC/ccportab.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chrfcu.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chdebug.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chtime.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chlists.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chalign.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chtrace.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chport.h:
../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/chcore.h:
../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/cmparams.h:
../../keyboard_core/tool/chibios/chibios/os/hal/boards/AT_START_F405/board.h:
../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/at32f402_405xx.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/core_cm4.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_version.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_compiler.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_gcc.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/mpu_armv7.h:
../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/mpu.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chtm.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chstats.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chobjects.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chsys.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chinstances.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chvt.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chschd.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chthreads.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chregistry.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chsem.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chmtx.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chcond.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chevents.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chmsg.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chlib.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chbsem.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmboxes.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmemcore.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmemheaps.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmempools.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chobjfifos.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chpipes.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chobjcaches.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chdelegates.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chjobs.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chfactory.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chdynamic.h:
../../keyboard_core/common/action_util.h:
../../keyboard_core/common/report.h:
../../keyboard_core/common/keycode.h:
../../keyboard_core/protocol/chibios/usb_main.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal.h:
../../keyboard_core/tool/chibios/chibios/os/hal/osal/rt-nil/osal.h:
halconf.h:
mcuconf.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/AT32F405xx/hal_lld.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/AT32F405xx/at32_registry.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/common/ARMCMx/nvic.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/common/ARMCMx/cache.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/common/ARMCMx/mpu_v7m.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/AT32F405xx/at32_crm.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/DMAv2/at32_dma.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/AT32F405xx/at32_dmamux.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/EXINTv1/at32_exint.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/AT32F405xx/at32_isr.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/TMRv1/at32_tmr.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_objects.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_streams.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_channels.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_files.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_ioblock.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_mmcsd.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_persistent.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_flash.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_buffers.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_queues.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_pal.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/GPIOv2/hal_pal_lld.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/GPIOv2/at32_gpio.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_adc.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/ADCv2/hal_adc_lld.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_can.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_crypto.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_dac.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_efl.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_gpt.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/TMRv1/hal_gpt_lld.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/TMRv1/at32_tmr.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_i2c.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/I2Cv2/hal_i2c_lld.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_i2s.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_icu.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_eicu.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_timcap.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_mac.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_pwm.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_rtc.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_serial.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/USARTv2/hal_serial_lld.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_sdc.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_sio.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_spi.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_spi_v2.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/SPIv2/hal_spi_v2_lld.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_trng.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_uart.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/USARTv2/hal_uart_lld.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_usb.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/OTGv1/hal_usb_lld.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/OTGv1/at32_otg.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_wdg.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_wspi.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_eeprom.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_crc.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/CRCv1/hal_crc_lld.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_st.h:
../../keyboard_core/tool/chibios/chibios/os/hal/ports/AT32/LLD/SYSTICKv1/hal_st_lld.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_mmc_spi.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_serial_usb.h:
../../keyboard_core/tool/chibios/chibios/os/hal/include/hal_usb_cdc.h:
../../keyboard_core/common/matrix.h:
../../keyboard_core/common/timer.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\string.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_locale.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\strings.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\string.h:
../../keyboard_core/common/action.h:
../../keyboard_core/common/keyboard.h:
../../keyboard_core/common/action_macro.h:
../../keyboard_core/common/progmem.h:
