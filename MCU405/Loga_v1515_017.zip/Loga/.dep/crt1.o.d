build/obj/crt1.o: \
 ../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/compilers/GCC/crt1.c \
 config.h socd.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_default_types.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\features.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_newlib_version.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_intsup.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdbool.h \
 ../../keyboard_core/common/matrix.h rappy_snappy.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/cmparams.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/boards/AT_START_F405/board.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/at32f402_405xx.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/core_cm4.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_version.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_compiler.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_gcc.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/mpu_armv7.h
config.h:
socd.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_default_types.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\features.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_newlib_version.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_intsup.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdbool.h:
../../keyboard_core/common/matrix.h:
rappy_snappy.h:
../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/cmparams.h:
../../keyboard_core/tool/chibios/chibios/os/hal/boards/AT_START_F405/board.h:
../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/at32f402_405xx.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/core_cm4.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_version.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_compiler.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_gcc.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/mpu_armv7.h:
