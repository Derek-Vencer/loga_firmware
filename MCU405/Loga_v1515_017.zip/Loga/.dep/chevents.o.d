build/obj/chevents.o: \
 ../../keyboard_core/tool/chibios/chibios/os/rt/src/chevents.c config.h \
 socd.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_default_types.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\features.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_newlib_version.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_intsup.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_stdint.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdbool.h \
 ../../keyboard_core/common/matrix.h rappy_snappy.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/ch.h \
 ../../keyboard_core/tool/chibios/chibios/os/license/chlicense.h \
 ../../keyboard_core/tool/chibios/chibios/os/license/chversion.h \
 ../../keyboard_core/tool/chibios/chibios/os/license/chcustomer.h \
 chconf.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chchecks.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chrestrictions.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chearly.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ports/ARM-common/chtypes.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stddef.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/portability/GCC/ccportab.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chrfcu.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chdebug.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chtime.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chlists.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chalign.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chtrace.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chport.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/chcore.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/cmparams.h \
 ../../keyboard_core/tool/chibios/chibios/os/hal/boards/AT_START_F405/board.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/at32f402_405xx.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/core_cm4.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_version.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_compiler.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_gcc.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/mpu_armv7.h \
 ../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/mpu.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chtm.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chstats.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chobjects.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chsys.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chinstances.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chvt.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chschd.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chthreads.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chregistry.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chsem.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chmtx.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chcond.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chevents.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chmsg.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chlib.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chbsem.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmboxes.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmemcore.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmemheaps.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmempools.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chobjfifos.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chpipes.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chobjcaches.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chdelegates.h \
 d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdarg.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chjobs.h \
 ../../keyboard_core/tool/chibios/chibios/os/oslib/include/chfactory.h \
 ../../keyboard_core/tool/chibios/chibios/os/rt/include/chdynamic.h
config.h:
socd.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\machine\_default_types.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\features.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\_newlib_version.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_intsup.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\arm-none-eabi\include\sys\_stdint.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdbool.h:
../../keyboard_core/common/matrix.h:
rappy_snappy.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/ch.h:
../../keyboard_core/tool/chibios/chibios/os/license/chlicense.h:
../../keyboard_core/tool/chibios/chibios/os/license/chversion.h:
../../keyboard_core/tool/chibios/chibios/os/license/chcustomer.h:
chconf.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chchecks.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chrestrictions.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chearly.h:
../../keyboard_core/tool/chibios/chibios/os/common/ports/ARM-common/chtypes.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stddef.h:
../../keyboard_core/tool/chibios/chibios/os/common/portability/GCC/ccportab.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chrfcu.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chdebug.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chtime.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chlists.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chalign.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chtrace.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chport.h:
../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/chcore.h:
../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/cmparams.h:
../../keyboard_core/tool/chibios/chibios/os/hal/boards/AT_START_F405/board.h:
../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/at32f402_405xx.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/core_cm4.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_version.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_compiler.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/cmsis_gcc.h:
../../keyboard_core/tool/chibios/chibios/os/common/ext/ARM/CMSIS/Core/Include/mpu_armv7.h:
../../keyboard_core/tool/chibios/chibios/os/common/ports/ARMv7-M/mpu.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chtm.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chstats.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chobjects.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chsys.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chinstances.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chvt.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chschd.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chthreads.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chregistry.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chsem.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chmtx.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chcond.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chevents.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chmsg.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chlib.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chbsem.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmboxes.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmemcore.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmemheaps.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chmempools.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chobjfifos.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chpipes.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chobjcaches.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chdelegates.h:
d:\at32ide\platform\tools\gcc-arm-none-eabi-10.3-2021.10\lib\gcc\arm-none-eabi\10.3.1\include\stdarg.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chjobs.h:
../../keyboard_core/tool/chibios/chibios/os/oslib/include/chfactory.h:
../../keyboard_core/tool/chibios/chibios/os/rt/include/chdynamic.h:
