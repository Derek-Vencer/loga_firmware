build/obj/vectors.o: \
 ../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/compilers/GCC/vectors.S \
 ../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/cmparams.h
../../keyboard_core/tool/chibios/chibios/os/common/startup/ARMCMx/devices/AT32F402_405xx/cmparams.h:
