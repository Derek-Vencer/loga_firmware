
/*
    Copyright (C) 2023 iOne Electrionc
*/

# include "hal.h"
# include "led_driver.h"
# include "pin_defs.h"
#include "led_type2.h"
#include "led_type2RGBTable.h"

SPIConfig ledDriver_spiConfig[LED_DriverCount];
//spicallback_t endCB[LED_DriverCount];


uint8_t hwSPI_Tx_Fifo[200];
uint8_t hwSPI_Rx_Fifo[200];
uint8_t bSPI_MasEndFlag;
uint32_t	wSPI_NBytes;
uint32_t	wSPI_Get_Pointer;
uint32_t wSPI_Send_Pointer;

void ledDriver_end1(void);
void ledDriver_end2(void);
void ledDriver_end3(void);

void ledDriver_init(void){

	palSetLineMode(SPI_LED_SDB_PIN, PAL_MODE_OUTPUT_PUSHPULL);							//SDB
	palClearLine(SPI_LED_SDB_PIN);
	palSetLineMode(SPI_LED_CS1_PIN, PAL_MODE_OUTPUT_PUSHPULL);							//CS1
	palSetLineMode(SPI_LED_CS2_PIN, PAL_MODE_OUTPUT_PUSHPULL);							//CS2
	palSetLineMode(SPI_LED_CS3_PIN, PAL_MODE_OUTPUT_PUSHPULL);							//CS3

	palSetLineMode(SPI_LED_SCK_PIN, PAL_MODE_ALTERNATE(SPI_LED_SCK_PAL_MODE));	//SCK
	palSetLineMode(SPI_LED_MOSI_PIN, PAL_MODE_ALTERNATE(SPI_LED_MOSI_PAL_MODE));	//MOSI
	palSetLineMode(SPI_LED_MISO_PIN, PAL_MODE_ALTERNATE(SPI_LED_MISO_PAL_MODE));	//MISO

	for (uint8_t i=0; i<LED_DriverCount; i++){
		ledDriver_spiConfig[i].circular = false;
		ledDriver_spiConfig[i].slave = false;
		ledDriver_spiConfig[i].error_cb = NULL;
//		ledDriver_spiConfig[i].ctrl1 = 55;		//55:24.8k	45:1.72Mhz
		ledDriver_spiConfig[i].ctrl1 = 53;		//55:24.8k	45:1.72Mhz
//		ledDriver_spiConfig[i].ctrl1 = 0x31;		//55:24.8k	45:1.72Mhz
//		ledDriver_spiConfig[i].ctrl1 = 0x48;		//55:24.8k	45:1.72Mhz
//		ledDriver_spiConfig[i].ctrl1 = SPI_CTRL1_MDIV_1024 | SPI_CTRL1_CLKPOL | SPI_CTRL1_CLKPHA;
		ledDriver_spiConfig[i].ctrl2 = 0U;
//		ledDriver_spiConfig[i].ctrl2 = SPI_CTRL2_TIEN;
//		ledDriver_spiConfig[i].ctrl2 = SPI_C2_DS_2 | SPI_CR2_DS_1 | SPI_CR2_DS_0;
	}


	ledDriver_spiConfig[0].data_cb = ledDriver_end1;
	ledDriver_spiConfig[0].ssport = SPI_LED_CS1_PORT;
	ledDriver_spiConfig[0].sspad = SPI_LED_CS1_PAD;

	ledDriver_spiConfig[1].data_cb = ledDriver_end2;
	ledDriver_spiConfig[1].ssport = SPI_LED_CS2_PORT;
	ledDriver_spiConfig[1].sspad = SPI_LED_CS2_PAD;

	ledDriver_spiConfig[2].data_cb = ledDriver_end3;
	ledDriver_spiConfig[2].ssport = SPI_LED_CS3_PORT;
	ledDriver_spiConfig[2].sspad = SPI_LED_CS3_PAD;

//	while(1){
	__LED_SetShutDownPinHigh;

	chThdSleepMilliseconds(10);
//	__LED_SetShutDownPinLow
//	chThdSleepMilliseconds(10);
//	}


}

void ledDriver_end1(void){

}

void ledDriver_end2(void){

}

void ledDriver_end3(void){

}


void SPI_W_3BYTE(uint8_t bPage, uint8_t bAddr, uint8_t bData)
{
	uint8_t port = 0;
	wSPI_NBytes = 3;
	hwSPI_Tx_Fifo[0] = (0x20|bPage);
	hwSPI_Tx_Fifo[1] = bAddr;
	hwSPI_Tx_Fifo[2] = bData;

	spiStart(&SPI_LED_DRIVER, &ledDriver_spiConfig[port]);
	spiSelect(&SPI_LED_DRIVER);
	spiSend(&SPI_LED_DRIVER, 3, hwSPI_Tx_Fifo);
	spiUnselect(&SPI_LED_DRIVER);
}


//bool SPI_W_NBYTE(uint8_t bPage, uint8_t bStartAddr, uint8_t blength);
void SPI_W_NBYTE(uint8_t bPage, uint8_t bStart_Addr, uint8_t blength)
{
	uint8_t port = 0;
	hwSPI_Tx_Fifo[0] = (0x20|bPage);
	hwSPI_Tx_Fifo[1] = bStart_Addr;
	wSPI_NBytes =	blength+2;
	spiStart(&SPI_LED_DRIVER, &ledDriver_spiConfig[port]);
	spiSelect(&SPI_LED_DRIVER);
	spiSend(&SPI_LED_DRIVER, blength, hwSPI_Tx_Fifo);
	spiUnselect(&SPI_LED_DRIVER);
										//SEL is high
	//Reset Variable
//	wSPI_Send_Pointer = 0;
}



uint8_t SPI_R_1BYTE(uint8_t port,uint8_t bPage, uint8_t bAddr){
uint8_t data [3];
uint8_t bData;
	data [0] = 0xA0 | bPage;
	data [1] = bAddr;
	spiStart(&SPI_LED_DRIVER, &ledDriver_spiConfig[port]);
	spiSelect(&SPI_LED_DRIVER);
	spiSend(&SPI_LED_DRIVER, 2, data);
	spiReceive(&SPI_LED_DRIVER, 1, bData);
	spiUnselect(&SPI_LED_DRIVER);
return bData;
}

void SPI_R_NBYTE(uint8_t port, uint8_t bPage, uint8_t bStartAddr, uint8_t blength, uint8_t *bData){
	uint8_t data [3];
	data [0] = 0xA0 | bPage;
	data [1] = bStartAddr;
//	data[0] = 0xAB;
//	data[1] = 0x00;
	spiStart(&SPI_LED_DRIVER, &ledDriver_spiConfig[port]);
	spiSelect(&SPI_LED_DRIVER);
	spiSend(&SPI_LED_DRIVER, 2, data);
	spiReceive(&SPI_LED_DRIVER, blength, bData);
	spiUnselect(&SPI_LED_DRIVER);
}

void SPI_R_NBYTE_ADDRESS(uint8_t port, uint8_t bPage, uint8_t bRegAddr, uint8_t blength,uint8_t*  bRxData)
{
	//volatile uint8_t	bDummyRead;
	uint8_t data[2];
	spiStart(&SPI_LED_DRIVER, &ledDriver_spiConfig[port]);
	data[0] = (0xA0|bPage);
	data[1] = bRegAddr;
	spiSelect(&SPI_LED_DRIVER);
	palSetLineMode(SPI_LED_MOSI_PIN, PAL_MODE_ALTERNATE(SPI_LED_MOSI_PAL_MODE));	//MOSI
	spiSend(&SPI_LED_DRIVER, 2, data);

	spiReceive(&SPI_LED_DRIVER, blength, bRxData);
	spiUnselect(&SPI_LED_DRIVER);
	palSetLineMode(SPI_LED_MOSI_PIN, PAL_MODE_OUTPUT_PUSHPULL);
	palClearLine(SPI_LED_MOSI_PIN);

}


void SPI_LevelShift_Test(void){

	uint8_t length = 1;
	uint8_t data[length];
	uint16_t count = 0;
	//ID_Register;
	while(1){
		//SPI_R_NBYTE(0, 0x0B, 0x1B, 2, data);
//		while(1);
//		LED_SledType2Init();
		uprintf ("\r\n");
		while(1){
//			SPI_R_NBYTE_ADDRESS(count %3, SPI_FRAME_FUNCTION_PAGE, 0, length, data);
			SPI_R_NBYTE_ADDRESS(1, 3, 0x11, length, data);
			UT_DelayNx10us(100);
//		SPI_R_NBYTE(0, 0x0B, 0x00, length, data);
//		uprintf ("Chip:%4d ",count++%3);
//		for (uint8_t i=0;i<length;i++){
//		uprintf ("%02X ",data[0],data[1]);
//		}
//		uprintf ("\r\n");
//		chThdSleepMilliseconds(100);
		}

//    while(1)
	LED_SledType2Init();
	while(1){
//		LED_SledType2Fun2();
		LED_SledType2RGBAnodeFun1(); //RGB panel turn on
		LED_SledType2RGBAnodeFun2(); //RGB(white) Single scan
		LED_SledType2ShutDownFun(); //H/W Shutdown
	}
//
	}
}


//===============================================================
/******************** (C) COPYRIGHT 2016 SONiX *******************************
* COMPANY:			SONiX
* DATE:					2016/03
* AUTHOR:				SA1
* IC:				SN32F240/230/220
* DESCRIPTION:	SLED1735 Demo Code
*____________________________________________________________________________
* REVISION	Date				User		Description
* 1.0				2016/03/17	SA1			1. First release
*____________________________________________________________________________
* THE PRESENT SOFTWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS TIME TO MARKET.
* SONiX SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT OR CONSEQUENTIAL
* DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT OF SUCH SOFTWARE
* AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION CONTAINED HEREIN
* IN CONNECTION WITH THEIR PRODUCTS.
*****************************************************************************/
/*_____ I N C L U D E S ____________________________________________________*/



/*_____ D E C L A R A T I O N S ____________________________________________*/
#define TYPE2_VAF_OPTION	TYPE2_ANODE_COLOR_RGB
		#define TYPE2_SINGLE_COLOR_RED		1
		#define TYPE2_SINGLE_COLOR_GREEN	2
		#define TYPE2_SINGLE_COLOR_BLUE		3
		#define TYPE2_CATHODE_COLOR_RGB	4
		#define TYPE2_ANODE_COLOR_RGB	5

/*_____ D E F I N I T I O N S ______________________________________________*/
//VAF Setting
//Each LED color type has an option of following to avoid LED blur.
#if (TYPE2_VAF_OPTION == TYPE2_SINGLE_COLOR_RED)
const uint8_t tabLED_Type2Vaf[36] = { //Reference SLED1735 Datasheet Type2 Map
																0x55, 0x55, 0x55, //CA1:	C1-A ~ C1-L
																0x55, 0x55, 0x55, //CA2:	C2-A ~ C2-L
																0x55, 0x55, 0x55, //CA3:	C3-A ~ C3-L
																0x55, 0x55, 0x55, //CA4:	C4-A ~ C4-L
																0x55, 0x55, 0x55, //CA5:	C5-A ~ C5-L
																0x55, 0x55, 0x55, //CA6:	C6-A ~ C6-L
																0x55, 0x55, 0x55, //CA7:	C7-A ~ C7-L
																0x55, 0x55, 0x55, //CA8:	C8-A ~ C8-L
																0x55, 0x55, 0x55, //CA9:	C9-A ~ C9-L
																0x55, 0x55, 0x55, //CA10:	C10-A ~ C10-L
																0x55, 0x55, 0x55, //CA11:	C11-A ~ C11-L
																0x55, 0x55, 0x55, //CA12:	C12-A ~ C12-L
															};

#elif (TYPE2_VAF_OPTION == TYPE2_SINGLE_COLOR_GREEN)
const uint8_t tabLED_Type2Vaf[36] = { //Reference SLED1735 Datasheet Type2 Map
																0x00, 0x00, 0x00, //CA1:	C1-A ~ C1-L
																0x00, 0x00, 0x00, //CA2:	C2-A ~ C2-L
																0x00, 0x00, 0x00, //CA3:	C3-A ~ C3-L
																0x00, 0x00, 0x00, //CA4:	C4-A ~ C4-L
																0x00, 0x00, 0x00, //CA5:	C5-A ~ C5-L
																0x00, 0x00, 0x00, //CA6:	C6-A ~ C6-L
																0x00, 0x00, 0x00, //CA7:	C7-A ~ C7-L
																0x00, 0x00, 0x00, //CA8:	C8-A ~ C8-L
																0x00, 0x00, 0x00, //CA9:	C9-A ~ C9-L
																0x00, 0x00, 0x00, //CA10:	C10-A ~ C10-L
																0x00, 0x00, 0x00, //CA11:	C11-A ~ C11-L
																0x00, 0x00, 0x00, //CA12:	C12-A ~ C12-L
															};

#elif (TYPE2_VAF_OPTION == TYPE2_SINGLE_COLOR_BLUE)
const uint8_t tabLED_Type2Vaf[36] = { //Reference SLED1735 Datasheet Type2 Map
																0xAA, 0xAA, 0xAA, //CA1:	C1-A ~ C1-L
																0xAA, 0xAA, 0xAA, //CA2:	C2-A ~ C2-L
																0xAA, 0xAA, 0xAA, //CA3:	C3-A ~ C3-L
																0xAA, 0xAA, 0xAA, //CA4:	C4-A ~ C4-L
																0xAA, 0xAA, 0xAA, //CA5:	C5-A ~ C5-L
																0xAA, 0xAA, 0xAA, //CA6:	C6-A ~ C6-L
																0xAA, 0xAA, 0xAA, //CA7:	C7-A ~ C7-L
																0xAA, 0xAA, 0xAA, //CA8:	C8-A ~ C8-L
																0xAA, 0xAA, 0xAA, //CA9:	C9-A ~ C9-L
																0xAA, 0xAA, 0xAA, //CA10:	C10-A ~ C10-L
																0xAA, 0xAA, 0xAA, //CA11:	C11-A ~ C11-L
																0xAA, 0xAA, 0xAA, //CA12:	C12-A ~ C12-L
															};

#elif (TYPE2_VAF_OPTION == TYPE2_CATHODE_COLOR_RGB)
const uint8_t tabLED_Type2Vaf[36] = { //Reference SLED1735 Datasheet Type2 Map
																0x41, 0x10, 0x04, //CA1:	C1-A ~ C1-L
																0x40, 0x10, 0x04, //CA2:	C2-A ~ C2-L
																0x44, 0x10, 0x04, //CA3:	C3-A ~ C3-L
																0x40, 0x10, 0x04, //CA4:	C4-A ~ C4-L
																0x04, 0x10, 0x04, //CA5:	C5-A ~ C5-L
																0x04, 0x11, 0x04, //CA6:	C6-A ~ C6-L
																0x04, 0x10, 0x04, //CA7:	C7-A ~ C7-L
																0x04, 0x01, 0x04, //CA8:	C8-A ~ C8-L
																0x04, 0x41, 0x04, //CA9:	C9-A ~ C9-L
																0x04, 0x01, 0x04, //CA10:	C10-A ~ C10-L
																0x04, 0x41, 0x00, //CA11:	C11-A ~ C11-L
																0x04, 0x41, 0x10, //CA12:	C12-A ~ C12-L
															};

#elif (TYPE2_VAF_OPTION == TYPE2_ANODE_COLOR_RGB)
const uint8_t tabLED_Type2Vaf[36] = { //Reference SLED1735 Datasheet Type2 Map
																0x50, 0x55, 0x55, //CA1:	C1-A ~ C1-L
																0x00, 0x00, 0x00, //CA2:	C2-A ~ C2-L
																0x00, 0x00, 0x00, //CA3:	C3-A ~ C3-L
																0x15, 0x54, 0x55, //CA4:	C4-A ~ C4-L
																0x00, 0x00, 0x00, //CA5:	C5-A ~ C5-L
																0x00, 0x00, 0x00, //CA6:	C6-A ~ C6-L
																0x55, 0x05, 0x55, //CA7:	C7-A ~ C7-L
																0x00, 0x00, 0x00, //CA8:	C8-A ~ C8-L
																0x00, 0x00, 0x00, //CA9:	C9-A ~ C9-L
																0x55, 0x55, 0x41, //CA10:	C10-A ~ C10-L
																0x00, 0x00, 0x00, //CA11:	C11-A ~ C11-L
																0x00, 0x00, 0x00, //CA12:	C12-A ~ C12-L
															};
#endif

/*_____ M A C R O S ________________________________________________________*/


/*_____ F U N C T I O N S __________________________________________________*/

/*****************************************************************************
* Function		: LED_Driver_Type2_Init
* Description	: Set Initial Value for SLED1735 (Type2 Matrix)
* Input			: None
* Output		: None
* Return		: None
* Note			: None
*****************************************************************************/
void LED_SledType2Init(void)
{
	uint32_t i;
	//Setting SLED1735 Ram Page to Function Page
	// System must go to SW shutdowm mode when initialization
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_SHUT_DOWN_MODE);
	//Setting Matrix Type = Type2
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, PICTURE_DISPLAY_REG, mskMATRIX_TYPE_TYPE2);
	//Setting Staggered Delay
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, STAGGERED_DELAY_REG, ((mskSTD4 & CONST_STD_GROUP4)|(mskSTD3 & CONST_STD_GROUP3)|(mskSTD2 & CONST_STD_GROUP2)|(mskSTD1 & CONST_STD_GROUP1)));
	//Enable Slew Rate control
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SLEW_RATE_CTL_REG, mskSLEW_RATE_CTL_EN);

	//===============================================================
	//VAF Control settings base on the LED type.
	//================================================================
	#if ((TYPE2_VAF_OPTION == TYPE2_CATHODE_COLOR_RGB)||(TYPE2_VAF_OPTION == TYPE2_ANODE_COLOR_RGB))
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, VAF_CTL_REG, (mskVAF2|mskVAF1));
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, VAF_CTL_REG2, (mskFORCEVAFCTL_VAFTIMECTL|(mskFORCEVAFTIME_CONST & 0x01)|mskVAF3));
	#else
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, VAF_CTL_REG, (mskVAF2|mskVAF1));
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, VAF_CTL_REG2, (mskFORCEVAFCTL_ALWAYSON|mskVAF3));
	#endif
	//================================================================

	//Setting LED driving current = 20mA and Enable current control
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, CURRENT_CTL_REG, (mskCURRENT_CTL_EN|CONST_CURRENT_STEP_20mA));

	//Init Frame1Page(Clear all Ram)
	LED_SPIType124ClearFrame1Page();

	//======================================================//
	//Init Type2 FrameVAFPage : Single R/G/B ,              //
	//Anode RGB or Cathode RGB have different VAF settings  //
	//which can choice by " TYPE2_VAF_OPTION ".             //
	//======================================================//
	for( i = 0; i< TYPE2_VAF_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = tabLED_Type2Vaf[i];
	}
	SPI_W_NBYTE(SPI_FRAME_LED_VAF_PAGE, TYPE2_VAF_FRAME_FIRST_ADDR, TYPE2_VAF_FRAME_LENGTH);

	//After initialization , system back to SW Normal mode.
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_NORMAL_MODE);
}

/*****************************************************************************
* Function		: LED_SledType2Fun1 : Column Scan
* Description	: Column by Column Light on LED Panel
* Input			: None
* Output		: None
* Return		: None
* Note			: None
*****************************************************************************/
void LED_SledType2Fun1(void)
{
	uint32_t i;

	// System must go to SW shutdowm mode
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_SHUT_DOWN_MODE);

	//=====================================//
	//Clear LED CTL Registers (Frame1Page) //
	//=====================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_LED_FRAME_CLR_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);

	//=========================================================//
	//SET PWM CTL Registers Value =0xFF(Max Value, Frame1Page) //
	//=========================================================//
	for( i = 0; i< TYPE2_PWM_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_PWM_FRAME_MAX_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_PWM_FRAME_FIRST_ADDR, TYPE2_PWM_FRAME_LENGTH);

	//System back to SW Normal mode.
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_NORMAL_MODE);

	//===============================//
	//Start Function1 light on Flow  //
	//===============================//
	//Write Frame1Page LED CTL Register:
	//mskLED_FRAME_REG_ADDR means Frame1Page Location address ,
	//mskLED_FRAME_REG_DATA means each bits mapping to one LED.

	//Turn On column 1 (12 LEDs) of LED panel
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x00), (mskLED_FRAME_REG_DATA & 0xFF));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x01), (mskLED_FRAME_REG_DATA & 0x0F));
	UT_DelayNms(500);;

	//Turn Off  column 1 of LED panel, and turn on current column 2
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x00), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x01), (mskLED_FRAME_REG_DATA & 0xF0));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x02), (mskLED_FRAME_REG_DATA & 0xFF));
	UT_DelayNms(500);;

	//Turn Off  column 2 of LED panel, and turn on current column 3
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x01), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x02), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x03), (mskLED_FRAME_REG_DATA & 0xFF));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x04), (mskLED_FRAME_REG_DATA & 0x0F));
	UT_DelayNms(500);;

	//Turn Off  column 3 of LED panel, and turn on current column 4
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x03), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x04), (mskLED_FRAME_REG_DATA & 0xF0));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x05), (mskLED_FRAME_REG_DATA & 0xFF));
	UT_DelayNms(500);;

	//Turn Off  column 4 of LED panel, and turn on current column 5
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x04), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x05), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x06), (mskLED_FRAME_REG_DATA & 0xFF));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x07), (mskLED_FRAME_REG_DATA & 0x0F));
	UT_DelayNms(500);;

	//Turn Off  column 5 of LED panel, and turn on current column 6
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x06), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x07), (mskLED_FRAME_REG_DATA & 0xF0));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x08), (mskLED_FRAME_REG_DATA & 0xFF));
	UT_DelayNms(500);;

	//Turn Off  column 6 of LED panel, and turn on current column 7
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x07), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x08), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x09), (mskLED_FRAME_REG_DATA & 0xFF));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0A), (mskLED_FRAME_REG_DATA & 0x0F));
	UT_DelayNms(500);;

	//Turn Off  column 7 of LED panel, and turn on current column 8
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x09), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0A), (mskLED_FRAME_REG_DATA & 0xF0));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0B), (mskLED_FRAME_REG_DATA & 0xFF));
	UT_DelayNms(500);;

	//Turn Off  column 8 of LED panel, and turn on current column 9
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0A), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0B), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0C), (mskLED_FRAME_REG_DATA & 0xFF));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0D), (mskLED_FRAME_REG_DATA & 0x0F));
	UT_DelayNms(500);;

	//Turn Off  column 9 of LED panel, and turn on current column 10
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0C), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0D), (mskLED_FRAME_REG_DATA & 0xF0));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0E), (mskLED_FRAME_REG_DATA & 0xFF));
	UT_DelayNms(500);;

	//Turn Off  column 10 of LED panel, and turn on current column 11
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0D), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0E), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0F), (mskLED_FRAME_REG_DATA & 0xFF));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x10), (mskLED_FRAME_REG_DATA & 0x0F));
	UT_DelayNms(500);;

	//Turn Off  column 11 of LED panel, and turn on current column 12
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x0F), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x10), (mskLED_FRAME_REG_DATA & 0xF0));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x11), (mskLED_FRAME_REG_DATA & 0xFF));
	UT_DelayNms(500);;

	//Turn Off  column 12 of LED panel
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x10), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
	SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR & 0x11), (mskLED_FRAME_REG_DATA & TYPE2_LED_FRAME_CLR_DATA));
}

/*****************************************************************************
* Function		: LED_SledType2Fun2 : Blink
* Description	: All LED of the Panel Blink
* Input			: None
* Output		: None
* Return		: None
* Note			: None
*****************************************************************************/
void LED_SledType2Fun2(void)
{
	uint32_t i;

	// System must go to SW shutdowm mode when Enable Blink Registers
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_SHUT_DOWN_MODE);

	//==============================//
	//Turn On Blink Funtion					//
	//==============================//
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, DISPLAY_OPTION_REG, (mskBLINK_FRAME_300|mskBLINK_EN|(mskBLINK_PERIOD_TIME_CONST & 0x03)));	//Setting Blink register

	//==============================//
	//Turn Off All LED  (Frame1Page)//
	//==============================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_LED_FRAME_CLR_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);

	//=============================================//
	//Turn On All Blink Control bits  (Frame1Page) //
	//=============================================//
	for( i = 0; i< TYPE2_BLINK_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_BLINK_FRAME_MAX_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_BLINK_FRAME_FIRST_ADDR, TYPE2_BLINK_FRAME_LENGTH);

	//=========================================================//
	//SET PWM CTL Registers Value =0xFF(Max Value, Frame1Page) //
	//=========================================================//
	for( i = 0; i< TYPE2_PWM_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_PWM_FRAME_MAX_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_PWM_FRAME_FIRST_ADDR, TYPE2_PWM_FRAME_LENGTH);

	//After Setting Blink Registers,system back to SW Normal mode.
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_NORMAL_MODE);

	//=================================//
	//Delay for Blink Frame Data ready //
	//=================================//
	chThdSleepMilliseconds(5);

	//==============================//
	//Turn On All LEDs  (Frame1Page)//
	//==============================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_LED_FRAME_MAX_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);

	//===================================//
	//Delay for observing Blink function //
	//===================================//
	chThdSleepMilliseconds(6500);

	//==============================//
	//Turn Off Blink Funtion				//
	//==============================//
	//Disable Blink
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, DISPLAY_OPTION_REG, (mskBLINK_FRAME_300|mskBLINK_DIS|(mskBLINK_PERIOD_TIME_CONST & 0x03)));
}

/*****************************************************************************
* Function		: LED_SledType2Fun3 : Single Scan
* Description	: Single LED move on the Panel
* Input			: None
* Output		: None
* Return		: None
* Note			: None
*****************************************************************************/
void LED_SledType2Fun3(void)
{
	uint32_t i, j , x;

	// System must go to SW shutdowm mode
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_SHUT_DOWN_MODE);

	//=====================================//
	//Clear LED CTL Registers (Frame1Page) //
	//=====================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_LED_FRAME_CLR_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);

	//=========================================================//
	//SET PWM CTL Registers Value =0xFF(Max Value, Frame1Page) //
	//=========================================================//
	for( i = 0; i< TYPE2_PWM_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_PWM_FRAME_MAX_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_PWM_FRAME_FIRST_ADDR, TYPE2_PWM_FRAME_LENGTH);

	//System back to SW Normal mode.
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_NORMAL_MODE);

	//===============================//
	//		Start Function3  Flow 		 //
	//===============================//
	//i loop for the Type2 LED control Registers' address
	for(i=0; i<TYPE2_LED_FRAME_LENGTH ; i++)
	{
		x = 0x01;
		//j loop for turn on each LED
		for(j=0; j<8 ; j++)
		{
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, i, x);			//turn on one LED
			x = (x<<1);
			chThdSleepMilliseconds(100);				//delay 100ms
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, i, 0);			//turn off current LED
		}
	}
}

/*****************************************************************************
* Function		: LED_SledType2Fun4 : Breath
* Description	: All LEDs of the Panel breathe
* Input			: None
* Output		: None
* Return		: None
* Note			: None
*****************************************************************************/
void LED_SledType2Fun4(void)
{
	uint32_t i;

	// System must go to SW shutdowm mode when Enable Breath Registers
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_SHUT_DOWN_MODE);

	//==============================//
	//Turn On Breath Funtion				//
	//==============================//
	//Breath Control 2, Extinguish Time is 7,	Continuous  Enable,	Breath Enable
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, BREATH_CTL_REG2, (mskBC_CONTINUOUS_BREATH_EN|mskBC_BREATH_EN|(mskBC_EXTINGUISH_TIME_CONST&0x07)));
	//Breath Control,Fade Out/In Time
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, BREATH_CTL_REG, ((mskBC_FADE_IN_TIME_CONST&0x07)|(mskBC_FADE_OUT_TIME_CONST&0x70)));

	//==============================//
	//Turn On All LED  (Frame1Page) //
	//==============================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_LED_FRAME_MAX_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);

	//=============================================//
	//Turn Off All Blink Control bits  (Frame1Page)//
	//=============================================//
	for( i = 0; i< TYPE2_BLINK_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_BLINK_FRAME_CLR_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_BLINK_FRAME_FIRST_ADDR, TYPE2_BLINK_FRAME_LENGTH);

	//=========================================================//
	//SET PWM CTL Registers Value =0xFF(Max Value, Frame1Page) //
	//=========================================================//
	for( i = 0; i< TYPE2_PWM_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_PWM_FRAME_MAX_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_PWM_FRAME_FIRST_ADDR, TYPE2_PWM_FRAME_LENGTH);

	//After Setting Breath Registers,system back to SW Normal mode.
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_NORMAL_MODE);

	//====================================//
	//Delay for observing Breath function //
	//====================================//
	chThdSleepMilliseconds(16500);

	//System back to SW Normal mode.
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_SHUT_DOWN_MODE);

	//==============================//
	//Turn Off Breath Funtion				//
	//==============================//
	//Breath Control 2, Extinguish Time is 0,	Continuous Disable, Breath Disable
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, BREATH_CTL_REG2, (mskBC_CONTINUOUS_BREATH_DIS|mskBC_BREATH_DIS));
	//Contorl Fade Out/In Time=0
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, BREATH_CTL_REG, ((mskBC_FADE_IN_TIME_CONST&0x00)|(mskBC_FADE_OUT_TIME_CONST&0x00)));
}

/*****************************************************************************
* Function		: LED_SledType2RGBAnodeFun1
* Description	: RGB LED Turn On
* Input			: None
* Output		: None
* Return		: None
* Note			: None
*****************************************************************************/
void LED_SledType2RGBAnodeFun1(void)
{

	uint32_t i;

	//=====================================//
	//Clear LED CTL Registers (Frame1Page) //
	//=====================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_LED_FRAME_CLR_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);

	//=========================================================//
	//SET PWM CTL Registers Value =0xFF(Max Value, Frame1Page) //
	//=========================================================//
	for( i = 0; i< TYPE2_PWM_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_PWM_FRAME_MAX_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_PWM_FRAME_FIRST_ADDR, TYPE2_PWM_FRAME_LENGTH);

	//=======================================//
	//Start Function1 light on RED LED Flow  //
	//=======================================//
	//Write Frame1Page LED CTL Register:
	//mskLED_FRAME_REG_ADDR means Frame1Page Location address ,
	//mskLED_FRAME_REG_DATA means each bits mapping to one LED.

	//=======================================//
	//			Turn On Red LED Panel					   //
	//=======================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = tabLED_Type2CTLAnodeRed[i];
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);
	//=========================//
	//			Delay for 3s		   //
	//=========================//
	chThdSleepMilliseconds(30);

	//=======================================//
	//			Turn On Green LED Panel				   //
	//=======================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = tabLED_Type2CTLAnodeGreen[i];
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);
	//=========================//
	//			Delay for 3s		   //
	//=========================//
	chThdSleepMilliseconds(30);

	//=======================================//
	//			Turn On Blue LED Panel				   //
	//=======================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = tabLED_Type2CTLAnodeBlue[i];
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);
	//=========================//
	//			Delay for 3s		   //
	//=========================//
	chThdSleepMilliseconds(30);

	//=======================================//
	//			Turn On RGB LED Panel				   //
	//=======================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = (tabLED_Type2CTLAnodeRed[i]|tabLED_Type2CTLAnodeGreen[i]|tabLED_Type2CTLAnodeBlue[i]);
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);
	//=========================//
	//			Delay for 3s		   //
	//=========================//
	chThdSleepMilliseconds(30);
}


/*****************************************************************************
* Function		: LED_SledType2RGBAnodeFun2 : Single Scan
* Description	: RGB LED move on the Panel
* Input			: None
* Output		: None
* Return		: None
* Note			: None
*****************************************************************************/
void LED_SledType2RGBAnodeFun2(void)
{
	uint32_t i;

	//=====================================//
	//Clear LED CTL Registers (Frame1Page) //
	//=====================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_LED_FRAME_MAX_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);

	//=========================================================//
	//SET PWM CTL Registers Value =0x00(Frame1Page) //
	//=========================================================//
	for( i = 0; i< TYPE2_PWM_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_PWM_FRAME_CLR_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_PWM_FRAME_FIRST_ADDR, TYPE2_PWM_FRAME_LENGTH);

	//===============================//
	//		Start Function3  Flow 		 //
	//===============================//
	//i loop for the Type2 RED LED control Registers' address
	for(i=0; i<TYPE2_RGB_ANODE_PWM_LENGTH ; i++)
	{
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, tabLED_Type2PWMCTLAnodeRed[i] , 	TYPE2_PWM_FRAME_MAX_DATA);		//turn on one LED
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, tabLED_Type2PWMCTLAnodeGreen[i] , TYPE2_PWM_FRAME_MAX_DATA);		//turn on one LED
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, tabLED_Type2PWMCTLAnodeBlue[i] , 	TYPE2_PWM_FRAME_MAX_DATA);		//turn on one LED
			chThdSleepMilliseconds(100);				//delay 100ms
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, tabLED_Type2PWMCTLAnodeRed[i] , 	TYPE2_PWM_FRAME_CLR_DATA);		//turn off one LED
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, tabLED_Type2PWMCTLAnodeGreen[i] ,	TYPE2_PWM_FRAME_CLR_DATA);		//turn off one LED
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, tabLED_Type2PWMCTLAnodeBlue[i] , 	TYPE2_PWM_FRAME_CLR_DATA);		//turn off one LED
	}
}

/*****************************************************************************
* Function		: LED_SledType2RGBCathodeFun1
* Description	: RGB LED Turn On
* Input			: None
* Output		: None
* Return		: None
* Note			: None
*****************************************************************************/
void LED_SledType2RGBCathodeFun1(void)
{

	uint32_t i;

	//=====================================//
	//Clear LED CTL Registers (Frame1Page) //
	//=====================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_LED_FRAME_CLR_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);

	//=========================================================//
	//SET PWM CTL Registers Value =0xFF(Max Value, Frame1Page) //
	//=========================================================//
	for( i = 0; i< TYPE2_PWM_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_PWM_FRAME_MAX_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_PWM_FRAME_FIRST_ADDR, TYPE2_PWM_FRAME_LENGTH);

	//=======================================//
	//Start Function1 light on RED LED Flow  //
	//=======================================//
	//Write Frame1Page LED CTL Register:
	//mskLED_FRAME_REG_ADDR means Frame1Page Location address ,
	//mskLED_FRAME_REG_DATA means each bits mapping to one LED.

	//=======================================//
	//			Turn On Red LED Panel					   //
	//=======================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = tabLED_Type2CTLCathodeRed[i];
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);
	//=========================//
	//			Delay for 3s		   //
	//=========================//
	chThdSleepMilliseconds(30);

	//=======================================//
	//			Turn On Green LED Panel				   //
	//=======================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = tabLED_Type2CTLCathodeGreen[i];
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);
	//=========================//
	//			Delay for 3s		   //
	//=========================//
	chThdSleepMilliseconds(30);

	//=======================================//
	//			Turn On Blue LED Panel				   //
	//=======================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = tabLED_Type2CTLCathodeBlue[i];
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);
	//=========================//
	//			Delay for 3s		   //
	//=========================//
	chThdSleepMilliseconds(30);

	//=======================================//
	//			Turn On RGB LED Panel				   //
	//=======================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = (tabLED_Type2CTLCathodeRed[i]|tabLED_Type2CTLCathodeGreen[i]|tabLED_Type2CTLCathodeBlue[i]);
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);
	//=========================//
	//			Delay for 3s		   //
	//=========================//
	chThdSleepMilliseconds(30);
}

/*****************************************************************************
* Function		: LED_SledType2RGBCathodeFun2 : Single Scan
* Description	: RGB LED move on the Panel
* Input			: None
* Output		: None
* Return		: None
* Note			: None
*****************************************************************************/
void LED_SledType2RGBCathodeFun2(void)
{

	uint32_t i;

	//=====================================//
	//Clear LED CTL Registers (Frame1Page) //
	//=====================================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_LED_FRAME_MAX_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);


	//=========================================================//
	//SET PWM CTL Registers Value =0x00(Frame1Page) //
	//=========================================================//
	for( i = 0; i< TYPE2_PWM_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_PWM_FRAME_CLR_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_PWM_FRAME_FIRST_ADDR, TYPE2_PWM_FRAME_LENGTH);

	//===============================//
	//		Start Function3  Flow 		 //
	//===============================//
	//i loop for the Type2 RED LED control Registers' address
	for(i=0; i<TYPE2_RGB_CATHODE_PWM_LENGTH ; i++)
	{
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, tabLED_Type2PWMCTLCathodeRed[i] ,	 	TYPE2_PWM_FRAME_MAX_DATA);		//turn on one LED
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, tabLED_Type2PWMCTLCathodeGreen[i] , TYPE2_PWM_FRAME_MAX_DATA);		//turn on one LED
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, tabLED_Type2PWMCTLCathodeBlue[i] , 	TYPE2_PWM_FRAME_MAX_DATA);		//turn on one LED
			chThdSleepMilliseconds(100);				//delay 100ms
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, tabLED_Type2PWMCTLCathodeRed[i] , 	TYPE2_PWM_FRAME_CLR_DATA);		//turn off one LED
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, tabLED_Type2PWMCTLCathodeGreen[i] , TYPE2_PWM_FRAME_CLR_DATA);		//turn off one LED
			SPI_W_3BYTE(SPI_FRAME_ONE_PAGE, tabLED_Type2PWMCTLCathodeBlue[i] , 	TYPE2_PWM_FRAME_CLR_DATA);		//turn off one LED
	}
}

/*****************************************************************************
* Function		: LED_SledType2ShutDownFun
* Description	: RLED Shutdown
* Input			: None
* Output		: None
* Return		: None
* Note			: None
*****************************************************************************/
void LED_SledType2ShutDownFun(void)
{

	uint32_t i;

	//System into S/W Shutdown	mode
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_SHUT_DOWN_MODE);

	//==============================//
	//Turn Off All LED  (Frame1Page)//
	//==============================//
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_LED_FRAME_CLR_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);

	//into H/W Shutdown
	__LED_SetShutDownPinLow

	//==============================//
	//H/W shutdown mode							//
	//==============================//
	chThdSleepMilliseconds(1000);				//delay 1000ms
	//leave H/W Shutdown
	__LED_SetShutDownPinHigh
//	UT_DelayNx10us(20);				//!!delay 200us
	//==============================//
	//Turn On All LED  (Frame1Page)//
	//==============================//
	/*
	for( i = 0; i< TYPE2_LED_FRAME_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE2_LED_FRAME_MAX_DATA;
	}
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, TYPE2_LED_FRAME_FIRST_ADDR, TYPE2_LED_FRAME_LENGTH);
	*/

	//System leave S/W Shutdown	mode, return Normal mode
	SPI_W_3BYTE(SPI_FRAME_FUNCTION_PAGE, SW_SHUT_DOWN_REG, mskSW_NORMAL_MODE);
//	UT_DelayNx10us(20);				//!!delay 200us
}


/*****************************************************************************
* Function		: LED_SPIType124ClearFrame1Page by SPI
* Description	: Clear Type1 / 2 /4  Frame 1 Page
* Input			: None
* Output		: None
* Return		: None
* Note			: None
*****************************************************************************/
void LED_SPIType124ClearFrame1Page(void)
{
	uint32_t i;
	//Write Data=0x00 to bI2C_MasTxData[] FIFO to CLR SLED1735 Ram
	for( i = 0; i< TYPE1_2_4_FRAME1PAGE_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE1_LED_FRAME_CLR_DATA;
	}
	//Setting SLED1735 Ram Page to Frame 1 Page
	//send 0xB3 bytes length Data From address 0x00
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR&0x00), TYPE1_2_4_FRAME1PAGE_LENGTH);
}


/*****************************************************************************
* Function		: LED_SPIType3ClearFrame1Page
* Description	: Clear Type3 Frame 1 Page
* Input			: None
* Output		: None
* Return		: None
* Note			: Type3 Frame Page Address and Length different than Type1/2/4
*****************************************************************************/
void LED_SPIType3ClearFrame1Page(void)
{
	uint32_t i;
	//Setting SLED1735 Ram Page to Frame 1 Page
	//Write Data=0x00 to hwSPI_Tx_Fifo[] FIFO to CLR SLED1735 Ram
	for( i = 0; i< TYPE3_FRAME1PAGE_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE3_LED_FRAME_CLR_DATA;
	}
	//Clear SLED1735 Ram Page to Frame 1 Page
	//send 0xB3 bytes length Data From address 0x00
	SPI_W_NBYTE(SPI_FRAME_ONE_PAGE, (mskLED_FRAME_REG_ADDR&0x00), TYPE3_FRAME1PAGE_LENGTH);
}


/*****************************************************************************
* Function		: LED_SPIType3ClearFrame2Page
* Description	: Clear Type3 Frame 2 Page
* Input			: None
* Output		: None
* Return		: None
* Note			: Type3 Frame Page Address and Length different than Type1/2/4
*****************************************************************************/
void LED_SPIType3ClearFrame2Page(void)
{
	uint32_t i;
	//Setting SLED1735 Ram Page to Frame 2 Page

	//Write Data=0x00 to hwSPI_Tx_Fifo[] FIFO to CLR SLED1735 Ram
		for( i = 0; i< TYPE3_FRAME2PAGE_LENGTH ; i++)
	{
		hwSPI_Tx_Fifo[i+2] = TYPE3_LED_FRAME_CLR_DATA;
	}
	//Clear SLED1735 Ram Page to Frame 1 Page
	//send 0xB3 bytes length Data From address 0x00
	SPI_W_NBYTE(SPI_FRAME_TWO_PAGE, (mskLED_FRAME_REG_ADDR&0x00), TYPE3_FRAME2PAGE_LENGTH);
}

/*****************************************************************************
* Function		: UT_DelayNx10us
* Description	: Delay N x 10 us @ Fcpu = 12MHz
* Input			: N
* Output		: None
* Return		: None
* Note			: May have some deviation (+/-10%)
*****************************************************************************/
void UT_DelayNx10us (uint32_t N)
{
	N*=210;
  while (N--);
}

/*****************************************************************************
* Function		: UT_DelayNms
* Description	: Delay N ms @ Fcpu = 12MHz
* Input			: N
* Output		: None
* Return		: None
* Note			: May have some deviation (+/-10%)
*****************************************************************************/
void UT_DelayNms (uint32_t N)
{
//	while (N--)
//	{
//		SN_WDT->FEED = 0x5AFA55AA;	//Feed WDT
//		UT_DelayNx10us(100);				//10us x 100 = 1ms
//	}
	chThdSleepMilliseconds(N);
}

