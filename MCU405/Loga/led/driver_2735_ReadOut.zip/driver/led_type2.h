#ifndef __SN32F240_LED_Type2_H
#define __SN32F240_LED_Type2_H

/*_____ I N C L U D E S ____________________________________________________*/

/*_____ D E F I N I T I O N S ______________________________________________*/


/*_____ D E C L A R A T I O N S ____________________________________________*/
extern	void LED_SledType2Init(void);
extern	void LED_SledType2Fun1(void);
extern	void LED_SledType2Fun2(void);	
extern	void LED_SledType2Fun3(void);	
extern	void LED_SledType2Fun4(void);	
extern	void LED_SledType2RGBAnodeFun1(void);
extern	void LED_SledType2RGBAnodeFun2(void);															
extern	void LED_SledType2RGBCathodeFun1(void);
extern	void LED_SledType2RGBCathodeFun2(void);	
extern	void LED_SledType2ShutDownFun(void);	
#endif	/*__SN32F240_LED_Type2_H*/
