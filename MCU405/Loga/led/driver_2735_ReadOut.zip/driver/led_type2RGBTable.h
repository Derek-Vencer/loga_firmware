#ifndef __SN32F240_LED_Type2RGBTable_H
#define __SN32F240_LED_Type2RGBTable_H

/*_____ I N C L U D E S ____________________________________________________*/

/*_____ D E F I N I T I O N S ______________________________________________*/


	//---------------------------------------------------------------------
	//															
	//				Type2 RGB Anod Control Table														
	//														
	//---------------------------------------------------------------------
	//Address 0x00 bits[7:2] 			/ 0x01 bits[3:0] 	/ 0x02 					 			=> Red	 D1~D10
	//Address 0x00					 			/ 0x01 bits[7:6] 	/ 0x02 bits[7:0] 			=> Green D1~D10		
	//Address 0x03 bits[7:2] / 0x04 bits[3:0] / 0x05					 						=> Blue	 D1~D10	
	//---------------------------------------------------------------------
	//Address 0x03					 			/ 0x04 bits[6:4] 	/ 0x05 bits[7:1] 			=> Red	 D11~D20
	//Address 0x06 bits[7:5][2:0] / 0x07 bits[3:0] 	/ 0x08					 			=> Green D11~D20
	//Address 0x06					 / 0x07 bits[6:4] / 0x08 bits[6:0] 						=> Blue	 D11~D20
	//----------------------------------------------------------------------
	//Address 0x09 bits[5:0] 			/ 0x0A bits[3:0] 	/ 0x0B					 			=> Red	 D21~D30
	//Address 0x09							 	/ 0x0A bits[7:4] 	/ 0x0B bits[7:4][1:0] => Green D21~D30
	//Address 0x0C bits[5:0] / 0x0D bits[4:0] / 0x0E					 						=> Blue	 D21~D30
	//---------------------------------------------------------------------
	//Address 0x0C					 			/ 0x0D bits[7:4] 	/ 0x0E bits[7][4:0] 	=> Red	 D31~D40
	//Address 0x0F bits[7:0] 			/ 0x10 bits[3][0] / 0x11					 			=> Green D31~D40
	//Address 0x0F					 / 0x10 bits[7:4] / 0x11 bits[7][4:0] 				=> Blue	 D31~D40
	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	//LUT for Frame1Page : LED Control and Blink Control Ram 
	//Notice: This Table setting the R/G/B LEDs mapping value,
	//				Setting start Address from 0x00 to 0x11 : LED Control Ram
	//				Setting start Address from 0x12 to 0x23 : Blink Control Ram
	//----------------------------------------------------------------------
		
const uint8_t tabLED_Type2CTLAnodeRed[18] = { //Reference SLED1735 Datasheet Type2 Map
																0xFC,	0x0F, 0x00,	//Address 0x00 bits[7:2] 			/ 0x01 bits[3:0] 	/ 0x02 					 			=> Red	 D1~D10
																0x00, 0x70, 0xFE,	//Address 0x03					 			/ 0x04 bits[6:4] 	/ 0x05 bits[7:1] 			=> Red	 D11~D20
																0x00, 0x00, 0x00,	//Address 0x06					 			/ 0x07 				  	/ 0x08 
																0x3F, 0x0F, 0x00,	//Address 0x09 bits[5:0] 			/ 0x0A bits[3:0] 	/ 0x0B					 			=> Red	 D21~D30
																0x00, 0xF0, 0x9F,	//Address 0x0C					 			/ 0x0D bits[7:4] 	/ 0x0E bits[7][4:0] 	=> Red	 D31~D40
																0x00, 0x00, 0x00,	//Address 0x0F					 			/ 0x10 				  	/ 0x11 
															};

const uint8_t tabLED_Type2CTLAnodeGreen[18] = { //Reference SLED1735 Datasheet Type2 Map
																0x00,	0xC0, 0xFF,	//Address 0x00					 			/ 0x01 bits[7:6] 	/ 0x02 bits[7:0] 			=> Green D1~D10	
																0x00, 0x00, 0x00,	//Address 0x03					 			/ 0x04 				  	/ 0x05 
																0xE7, 0x0F, 0x00,	//Address 0x06 bits[7:5][2:0] / 0x07 bits[3:0] 	/ 0x08					 			=> Green D11~D20	
																0x00, 0xF0, 0xF3,	//Address 0x09							 	/ 0x0A bits[7:4] 	/ 0x0B bits[7:4][1:0] => Green D21~D30
																0x00, 0x00, 0x00,	//Address 0x0C					 			/ 0x0D 				  	/ 0x0E 
																0xFF, 0x09, 0x00,	//Address 0x0F bits[7:0] 			/ 0x10 bits[3][0] / 0x11					 			=> Green D31~D40	
															};															
															
const uint8_t tabLED_Type2CTLAnodeBlue[18] = { //Reference SLED1735 Datasheet Type2 Map
																0x00,	0x00, 0x00,	//Address 0x00					 / 0x01 					/ 0x02
																0xFC, 0x0F, 0x00,	//Address 0x03 bits[7:2] / 0x04 bits[3:0] / 0x05					 						=> Blue	 D1~D10	
																0x00, 0x70, 0xFE,	//Address 0x06					 / 0x07 bits[6:4] / 0x08 bits[6:0] 						=> Blue	 D11~D20
																0x00, 0x00, 0x00, //Address 0x09					 / 0x0A 				  / 0x0B 
																0x3F, 0x0F, 0x00,	//Address 0x0C bits[5:0] / 0x0D bits[4:0] / 0x0E					 						=> Blue	 D21~D30
																0x00, 0xF0, 0x9F,	//Address 0x0F					 / 0x10 bits[7:4] / 0x11 bits[7][4:0] 				=> Blue	 D31~D40	
															};		
																													
//Table Index means the number of LED, and the data of table means PWM control ram address															
const uint8_t tabLED_Type2PWMCTLAnodeRed[40] = { //Reference SLED1735 Datasheet Type2 Map
																0x26,	0x27, 0x28, 0x29, 0x2A, 0x2B,	0x2C, 0x2D, 0x2E,	0x2F, 	// Red D1~D10 PWM CTL Mapping address
																0x48,	0x49, 0x4A, 0x4D,	0x4E, 0x4F, 0x50,	0x51, 0x52, 0x53, 	// Red D11~D20 PWM CTL Mapping address
																0x6C,	0x6D, 0x6E, 0x6F, 0x70, 0x71,	0x74,	0x75, 0x76, 0x77,		// Red D21~D30 PWM CTL Mapping address
																0x90,	0x91, 0x92, 0x93, 0x94, 0x95,	0x96, 0x97, 0x98,	0x9B, 	// Red D31~D40 PWM CTL Mapping address
															};							

//Table Index means the number of LED, and the data of table means PWM control ram address																	
const uint8_t tabLED_Type2PWMCTLAnodeGreen[40] = { //Reference SLED1735 Datasheet Type2 Map
																0x32,	0x33, 0x34, 0x35, 0x36, 0x37,	0x38, 0x39, 0x3A,	0x3B, 	// Green D1~D10 PWM CTL Mapping address
																0x54,	0x55, 0x56, 0x59,	0x5A, 0x5B, 0x5C,	0x5D, 0x5E, 0x5F, 	// Green D11~D20 PWM CTL Mapping address
																0x78,	0x79, 0x7A, 0x7B, 0x7C, 0x7D,	0x80,	0x81, 0x82, 0x83,		// Green D21~D30 PWM CTL Mapping address
																0x9C,	0x9D, 0x9E, 0x9F, 0xA0, 0xA1,	0xA2, 0xA3, 0xA4,	0xA7, 	// Green D31~D40 PWM CTL Mapping address
															};															

//Table Index means the number of LED, and the data of table means PWM control ram address																	
const uint8_t tabLED_Type2PWMCTLAnodeBlue[40] = { //Reference SLED1735 Datasheet Type2 Map
																0x3E, 0x3F, 0x40, 0x41,	0x42, 0x43, 0x44,	0x45,	0x46, 0x47, 	// Blue D1~D10 PWM CTL Mapping address
																0x60,	0x61, 0x62, 0x65,	0x66, 0x67, 0x68,	0x69,	0x6A, 0x6B, 	// Blue D11~D20 PWM CTL Mapping address
																0x84,	0x85, 0x86, 0x87, 0x88, 0x89,	0x8C,	0x8D, 0x8E, 0x8F,		// Blue D21~D30 PWM CTL Mapping address
																0xA8,	0xA9, 0xAA, 0xAB, 0xAC, 0xAD,	0xAE, 0xAF, 0xB0,	0xB3, 	// Blue D31~D40 PWM CTL Mapping address
															};		

	//---------------------------------------------------------------------
	//															
	//				Type2 RGB Cathode Control Table														
	//														
	//---------------------------------------------------------------------
	//Address 0x00 bits[6][3][0] / 0x01 bits[7][1] 		/ 0x02 bits[5][2]	   => Red	  D1~D7
	//Address 0x00 bits[7][4][1] / 0x01 bits[2] 			/ 0x02 bits[6][3][0] => Green	 D1~D7
	//Address 0x00 bits[5][2] 	 / 0x01 bits[3][0] 		/ 0x02 bits[7][4][1] => Blue	 D1~D7
	//---------------------------------------------------------------------
	//Address 0x03 bits[6][3][1] / 0x04 bits[7][1] 		/ 0x05 bits[5][2]	   => Red	  D8~D14
	//Address 0x03 bits[7][4][0] / 0x04 bits[2] 			/ 0x05 bits[6][3][0] => Green	 D8~D14
	//Address 0x03 bits[5][2] 	 / 0x04 bits[3][0] 		/ 0x05 bits[7][4][1] => Blue	 D8~D14		
	//----------------------------------------------------------------------
	//Address 0x06 bits[6][1] 	 / 0x07 bits[5][1] 		/ 0x08 bits[5][2][0] => Red	  D15~21
	//Address 0x06 bits[7][2] 	 / 0x07 bits[6][4][2] / 0x08 bits[6][3] 	 => Green	 D15~D21	
	//Address 0x06 bits[3]	 	 	 / 0x07 bits[7][3][0] / 0x08 bits[7][4][1] => Blue	 D15~D21
	//---------------------------------------------------------------------
	//Address 0x09 bits[6][1] 	 / 0x0A bits[5][1] 		/ 0x0B bits[5][0]	   => Red	  D22~27
	//Address 0x09 bits[7][2] 	 / 0x0A bits[6][2] 		/ 0x0B bits[6][1] 	 => Green	 D22~D27
	//Address 0x09 bits[3] 	 		 / 0x0A bits[7][3][0] / 0x0B bits[7][2] 	 => Blue	 D22~D27
	//---------------------------------------------------------------------
	//Address 0x0C bits[7][4][1] / 0x0D bits[5][1] 		/ 0x0E bits[5][0]	   => Red	  D28~D34
	//Address 0x0C bits[5][2][0] / 0x0D bits[6][2] 		/ 0x0E bits[6][1] 	 => Green	 D28~D34
	//Address 0x0C bits[6][3] 	 / 0x0D bits[7][3][0] / 0x0E bits[7][2] 	 => Blue	 D28~D34
	//---------------------------------------------------------------------
	//Address 0x0F bits[7][4][1] / 0x10 bits[5] 	 		/ 0x11 bits[6][3][0] => Red	  D35~D41
	//Address 0x0F bits[5][2] 	 / 0x10 bits[6][4][0] / 0x11 bits[4][1] 	 => Green	 D35~D41	
	//Address 0x0F bits[6][3] 	 / 0x10 bits[7][1] 		/ 0x11 bits[7][5][2] => Blue	 D35~D41	
	//---------------------------------------------------------------------
	//---------------------------------------------------------------------
	//LUT for Frame1Page : LED Control and Blink Control Ram 
	//Notice: This Table setting the R/G/B LEDs mapping value,
	//				Setting start Address from 0x00 to 0x11 : LED Control Ram
	//				Setting start Address from 0x12 to 0x23 : Blink Control Ram
	//----------------------------------------------------------------------													
const uint8_t tabLED_Type2CTLCathodeRed[18] = { //Reference SLED1735 Datasheet Type2 Map
																0x49,	0x82, 0x24,	//Address 0x00 bits[6][3][0] / 0x01 bits[7][1] 		/ 0x02 bits[5][2]	   => Red	  D1~D7
																0x4A,	0x82, 0x24,	//Address 0x03 bits[6][3][1] / 0x04 bits[7][1] 		/ 0x05 bits[5][2]	   => Red	  D8~D14
																0x42,	0x22, 0x25,	//Address 0x06 bits[6][1] 	 / 0x07 bits[5][1] 		/ 0x08 bits[5][2][0] => Red	  D15~21
																0x42,	0x22, 0x21,	//Address 0x09 bits[6][1] 	 / 0x0A bits[5][1] 		/ 0x0B bits[5][0]	   => Red	  D22~27
																0x92,	0x22, 0x21,	//Address 0x0C bits[7][4][1] / 0x0D bits[5][1] 		/ 0x0E bits[5][0]	   => Red	  D28~D34
																0x92,	0x20, 0x49,	//Address 0x0F bits[7][4][1] / 0x10 bits[5] 	 		/ 0x11 bits[6][3][0] => Red	  D35~D41
															};

const uint8_t tabLED_Type2CTLCathodeGreen[18] = { //Reference SLED1735 Datasheet Type2 Map
																0x92,	0x04, 0x49,	//Address 0x00 bits[7][4][1] / 0x01 bits[2] 			/ 0x02 bits[6][3][0] => Green	 D1~D7
																0x91,	0x04, 0x49,	//Address 0x03 bits[7][4][0] / 0x04 bits[2] 			/ 0x05 bits[6][3][0] => Green	 D8~D14
																0x84,	0x54, 0x48,	//Address 0x06 bits[7][2] 	 / 0x07 bits[6][4][2] / 0x08 bits[6][3] 	 => Green	 D15~D21
																0x84,	0x44, 0x42,	//Address 0x09 bits[7][2] 	 / 0x0A bits[6][2] 		/ 0x0B bits[6][1] 	 => Green	 D22~D27
																0x25,	0x44, 0x42,	//Address 0x0C bits[5][2][0] / 0x0D bits[6][2] 		/ 0x0E bits[6][1] 	 => Green	 D28~D34
																0x24,	0x51, 0x12,	//Address 0x0F bits[5][2] 	 / 0x10 bits[6][4][0] / 0x11 bits[4][1] 	 => Green	 D35~D41
															};															
															
const uint8_t tabLED_Type2CTLCathodeBlue[18] = { //Reference SLED1735 Datasheet Type2 Map
																0x24,	0x09, 0x92,	//Address 0x00 bits[5][2] 	 / 0x01 bits[3][0] 		/ 0x02 bits[7][4][1] => Blue	 D1~D7	
																0x24,	0x09, 0x92,	//Address 0x03 bits[5][2] 	 / 0x04 bits[3][0] 		/ 0x05 bits[7][4][1] => Blue	 D8~D14	
																0x08,	0x89, 0x92,	//Address 0x06 bits[3]	 	 	 / 0x07 bits[7][3][0] / 0x08 bits[7][4][1] => Blue	 D15~D21
																0x08,	0x89, 0x84, //Address 0x09 bits[3] 	 		 / 0x0A bits[7][3][0] / 0x0B bits[7][2] 	 => Blue	 D22~D27
																0x48,	0x89, 0x84,	//Address 0x0C bits[6][3] 	 / 0x0D bits[7][3][0] / 0x0E bits[7][2] 	 => Blue	 D28~D34
																0x48,	0x82, 0xA4,	//Address 0x0F bits[6][3] 	 / 0x10 bits[7][1] 		/ 0x11 bits[7][5][2] => Blue	 D35~D41	
															};																
																																																			
//Table Index means the number of LED, and the data of table means PWM control ram address															
const uint8_t tabLED_Type2PWMCTLCathodeRed[48] = { //Reference SLED1735 Datasheet Type2 Ma
																0x24,	0x27, 0x2A, 0x2D, 0x33,	0x36, 0x39, 0x3D,	0x3F, 0x42,		// Red D1~D10 PWM CTL Mapping address
																0x45, 0x4B, 0x4E, 0x51, 0x55, 0x5A, 0x5D, 0x61,	0x64, 0x66,		// Red D11~D20 PWM CTL Mapping address
																0x69,	0x6D, 0x72, 0x75, 0x79, 0x7C,	0x81, 0x85, 0x88,	0x8B,		// Red D21~D30 PWM CTL Mapping address
																0x8D, 0x91,	0x94, 0x99, 0x9D, 0xA0, 0xA3, 0xA9, 0xAC,	0xAF, 	// Red D31~D40 PWM CTL Mapping address
																0xB2,																													// Red D41 PWM CTL Mapping address
															};							

//Table Index means the number of LED, and the data of table means PWM control ram address																	
const uint8_t tabLED_Type2PWMCTLCathodeGreen[48] = { //Reference SLED1735 Datasheet Type2 Map
																0x25,	0x28, 0x2B, 0x2E, 0x34,	0x37, 0x3A, 0x3C,	0x40, 0x43,		// Green D1~D10 PWM CTL Mapping address
																0x46,	0x4C, 0x4F, 0x52, 0x56,	0x5B, 0x5E, 0x62,	0x60, 0x67, 	// Green D11~D20 PWM CTL Mapping address
																0x6A,	0x6E, 0x73, 0x76, 0x7A, 0x7D,	0x82, 0x86, 0x89,	0x84, 	// Green D21~D30 PWM CTL Mapping address
																0x8E, 0x92,	0x95, 0x9A, 0x9E, 0xA1,	0xA4, 0xAA, 0xAD,	0xB0, 	// Green D31~D40 PWM CTL Mapping address
																0xA8,																													// Green 41 PWM CTL Mapping address
															};															

//Table Index means the number of LED, and the data of table means PWM control ram address																	
const uint8_t tabLED_Type2PWMCTLCathodeBlue[48] = { //Reference SLED1735 Datasheet Type2 Map
																0x26,	0x29, 0x2C, 0x2F, 0x35,	0x38, 0x3B, 0x3E,	0x41, 0x44,		// Blue D1~D10 PWM CTL Mapping address
																0x47,	0x4D, 0x50, 0x53, 0x57,	0x5C, 0x5F, 0x63,	0x65, 0x68, 	// Blue D11~D20 PWM CTL Mapping address
																0x6B,	0x6F, 0x74, 0x77, 0x7B, 0x7E,	0x83, 0x87, 0x8A,	0x8C, 	// Blue D21~D30 PWM CTL Mapping address
																0x8F, 0x93,	0x96, 0x9B, 0x9F, 0xA2, 0xA5, 0xAB, 0xAE,	0xB1, 	// Blue D31~D40 PWM CTL Mapping address
																0xB3,																													// Blue 41 PWM CTL Mapping address
															};																	
														
#endif	/*__SN32F240_LED_Type2RGBTable_H*/
