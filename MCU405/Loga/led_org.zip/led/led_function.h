#ifndef LED_FUNCTION_H_
#define LED_FUNCTION_H_


void led_cb(void);
void led_creatTask(void);
void led_init(uint8_t channel);
int uprintf(const char* fmt, ...);
void uart_init(void);
void setLightRunMode (uint8_t mode);
void via_controlSet(uint8_t *data);
void via_rapidValueSet(uint8_t * data);

#define LedNumbers 87+1
//#define LedNumbers 33+1
//#define LedNumbers 2+1
#ifdef minTriggerCheck
	#define defaultBright 0.75f
#else
//#define defaultBright 0.35f
#define defaultBright 1.0f
#endif

#define LED_DemoModes	10

#define LED_PresetModes	15

//typedef union {
//  uint32_t raw;
//  struct {
//    uint8_t red;
//    uint8_t green;
//    uint8_t blue;
//    uint8_t btight;
//  };
//} led_config_tapiFactory_Version

enum {
	keyMatrixMode_Normal = 0,
	keyMatrixMode_InitialPostionCalc,
	keyMatrixMode_TravelPostionCalc,
};

typedef struct {
	uint8_t red;
	uint8_t green;
	uint8_t blue;
} led_config_t;

typedef struct {
	int8_t rowA;
	int8_t colA;
} analogKey_Config_t;

typedef struct {
	bool enable;
	uint8_t colorMode;
	led_config_t LED;
	uint8_t brightness;
	//uint8_t speed;
	int16_t ranbowIndex;
	int8_t bright;
	bool direction;
	float lastBrightTemp;
} EffectrandonColor_t;

typedef struct {
	bool enable;
	uint8_t Mode;
	uint8_t Rainbow;
	uint8_t Brightness;
	uint8_t bright;
	uint8_t Speed;
	led_config_t LED;
	uint8_t bbreathvolume;
	uint8_t bFlashingVolume;
	uint16_t TimerBase;
} EffectMosArt_t;


typedef struct {
	bool enable;
	uint8_t Brightness;
	uint8_t bright;
	//uint8_t speed;
	led_config_t LED;
	bool direction;
	uint16_t timebase;
} EffectRanbowFlow_t;


typedef struct {
	uint8_t runMode;
	uint8_t effect;
	bool enable;
	uint8_t colorMode;
	uint8_t mode;
	uint8_t brightness;
	uint8_t speed;
	bool direction;
	uint32_t timeStamp;
	uint32_t interval;
} EffectStatus_t;


typedef struct {
	uint8_t effect;
	bool enable;
	uint32_t interval;
	uint8_t colorMode;
	uint8_t mode;
	led_config_t color;
	uint8_t brightness;
	uint8_t speed;
	bool direction;
} EffectStruct_t;



enum effectTypes{
	EffectIdle,
	EffectTypeRandColor,
	EffectTypeMosArt,
	EffectTypeRainbowFlow,
	EffectTypeColorBrith,
	EffectTypeKeytest,
	EffectTypeOff,
};

enum mosArtModes{
	mosArtStatic,
	mosArtBreath,
	mosArtFlash,
};

enum ranbowColors{
	red,
	orange,
	yellow,
	green,
	blue,
	indigo,
	violet,
	white,
	dummy,
	off
};

enum colorModes{
	single,
	ranbow,
};

enum ledRunModes{
	normalMode,
	demoMode,
	dynamticLightingMode,
	lastRunMode,
	testMode,
	offMode,
	volSpdMode,
};

enum ledDemoModeBuilderMode{
	newDemo,
	addDemoEffect,
	newPreset,
	addPresetEffect,
};


static const led_config_t rainbowColor[] = {
    {255, 0, 0},
    {192, 96, 0},
    {255, 255, 0},
    { 0, 255, 0},
    { 0, 0, 255},
    { 0, 255, 255},
    {255, 0, 255},
    {170, 170, 170},
    {255, 0, 0},
    {192, 96, 0},
};


static const int8_t ledKeyMatrix[MATRIX_ROWS][MATRIX_COLS] = {
		15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,-1,										//16
		16,17,18,19,20,21,22,23,24,25,26,27,28,20,30,31,32,										//17
		49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,33,										//17
		50,51,52,53,54,55,56,57,58,59,60,61,62,-1,-1,-1,-1,										//13
		75,74,73,72,71,70,69,68,67,66,65,64,63,-1,-1,-1,-1,										//13
		76,77,78,79,80,81,82,83,84,85,86,-1,-1,-1,-1,-1,-1,										//11
};
//Rainbow Flow Effect
//static const int8_t ledRemap[MATRIX_ROWS][MATRIX_COLS] = {
//		15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,-1,										//16
//		16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,										//17
//		49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,33,										//17
//		50,51,52,53,54,55,56,57,58,59,60,61,62,-1,-1,-1,-1,										//13
//		75,74,73,72,71,70,69,68,67,66,65,-1,64,-1,-1,63,-1,										//13
//		76,77,78,-1,-1,-1,79,-1,-1,-1,80,81,82,83,84,85,86,										//11
//};
static const int8_t ledRemap[MATRIX_ROWS][MATRIX_COLS] = {
		15,14,13,12,11,10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0,-1,			//16
		16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,			//17
		49,48,47,46,45,44,43,42,41,40,39,38,37,36,35,34,33,			//17
		50,51,52,53,54,55,56,57,58,59,60,61,62,-1,-1,-1,-1,			//13
		75,74,73,72,71,70,69,68,67,66,65,-1,64,-1,-1,63,-1,			//13
		76,77,78,-1,-1,-1,79,-1,-1,-1,80,81,82,83,84,85,86,			//11
};

uint8_t analogBtnFill (uint8_t group,uint8_t location,led_config_t color, uint16_t bright);
void ledAnalogMatrixzlocationTest(bool direction);

#endif /* LED_FUNCTION_H_ */
